package net.mcreator.sword.cultivation;

public enum CultivationTechnique {
    NONE("无", 0),
    SWORD_BASIC("基础剑法", 1),
    SWORD_INTERMEDIATE("中级剑法", 2),
    SWORD_ADVANCED("高级剑法", 3),
    SWORD_MASTER("剑圣", 4),
    BLADE_BASIC("基础刀法", 1),
    BLADE_INTERMEDIATE("中级刀法", 2),
    BLADE_ADVANCED("高级刀法", 3),
    BLADE_MASTER("刀神", 4),
    SPEAR_BASIC("基础枪法", 1),
    SPEAR_INTERMEDIATE("中级枪法", 2),
    SPEAR_ADVANCED("高级枪法", 3),
    SPEAR_MASTER("枪神", 4);

    private final String displayName;
    private final int level;

    CultivationTechnique(String displayName, int level) {
        this.displayName = displayName;
        this.level = level;
    }

    public String getDisplayName() {
        return displayName;
    }

    public int getLevel() {
        return level;
    }

    public double getDamageMultiplier() {
        return 1.0 + (level * 0.25);
    }
}
