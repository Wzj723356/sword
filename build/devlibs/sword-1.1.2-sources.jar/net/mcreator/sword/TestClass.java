package net.mcreator.sword;

public class TestClass {
    public static void main(String[] args) {
        System.out.println("Hello World");
    }
}