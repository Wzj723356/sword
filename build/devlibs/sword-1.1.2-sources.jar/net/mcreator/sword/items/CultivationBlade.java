package net.mcreator.sword.items;

import net.minecraft.world.item.SwordItem;
import net.minecraft.world.item.Tiers;
import net.minecraft.world.item.Item;

public class CultivationBlade extends SwordItem {
    public CultivationBlade() {
        super(Tiers.NETHERITE, 3, -2.2F, new Item.Properties());
    }
}
