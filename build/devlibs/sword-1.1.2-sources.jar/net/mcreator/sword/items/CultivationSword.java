package net.mcreator.sword.items;

import net.minecraft.world.item.SwordItem;
import net.minecraft.world.item.Tiers;
import net.minecraft.world.item.Item;

public class CultivationSword extends SwordItem {
    public CultivationSword() {
        super(Tiers.NETHERITE, 3, -2.4F, new Item.Properties());
    }
}
