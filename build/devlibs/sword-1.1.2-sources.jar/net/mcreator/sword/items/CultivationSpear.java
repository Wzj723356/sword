package net.mcreator.sword.items;

import net.minecraft.world.item.SwordItem;
import net.minecraft.world.item.Tiers;
import net.minecraft.world.item.Item;

public class CultivationSpear extends SwordItem {
    public CultivationSpear() {
        super(Tiers.NETHERITE, 4, -2.6F, new Item.Properties());
    }
}
