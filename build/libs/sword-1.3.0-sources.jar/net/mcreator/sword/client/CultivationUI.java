package net.mcreator.sword.client;

import net.mcreator.sword.cultivation.CultivationData;
import net.mcreator.sword.cultivation.CultivationManager;
import net.mcreator.sword.cultivation.CultivationRealm;
import net.mcreator.sword.network.CultivationClientPacketHandler;
import net.mcreator.sword.network.CultivationDataCache;
import net.minecraft.class_2561;
import net.minecraft.class_310;

public class CultivationUI {
    private static boolean waitingForData = false;
    
    public static void displayCultivationInfo() {
        class_310 mc = class_310.method_1551();
        if (mc.field_1724 == null) return;
        
        if (waitingForData) {
            mc.field_1724.method_7353(class_2561.method_43470("正在获取修为数据..."), false);
            return;
        }
        
        waitingForData = true;
        CultivationClientPacketHandler.requestCultivationData();
    }
    
    public static void onCultivationDataReceived() {
        class_310 mc = class_310.method_1551();
        if (mc.field_1724 == null) return;
        
        waitingForData = false;
        
        if (!CultivationDataCache.hasCachedData()) {
            mc.field_1724.method_7353(class_2561.method_43470("获取修为数据失败"), false);
            return;
        }
        
        var data = CultivationDataCache.getCachedData();
        CultivationRealm realm = data.getRealm();
        int currentExp = data.getCurrentExp();
        String rootName = data.getSpiritualRoot().getDisplayName();
        float progress = data.getExpProgress();
        
        class_2561 message = class_2561.method_43470("=== 修仙信息 ===")
            .method_10852(class_2561.method_43470("\n境界: " + realm.getDisplayName()))
            .method_10852(class_2561.method_43470("\n灵根: " + rootName))
            .method_10852(class_2561.method_43470("\n当前经验: " + currentExp))
            .method_10852(class_2561.method_43470("\n升级进度: " + String.format("%.1f%%", progress * 100)));
        
        mc.field_1724.method_7353(message, false);
    }
}
