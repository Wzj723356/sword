package net.mcreator.sword.client;

import net.mcreator.sword.cultivation.CultivationData;
import net.mcreator.sword.cultivation.CultivationRealm;
import net.mcreator.sword.network.CultivationDataCache;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;

public class CultivationHUD implements HudRenderCallback {
    private static boolean showHUD = true;
    
    public static void register() {
        HudRenderCallback.EVENT.register(new CultivationHUD());
    }
    
    public static void toggleHUD() {
        showHUD = !showHUD;
    }
    
    public static boolean isHUDVisible() {
        return showHUD;
    }
    
    @Override
    public void onHudRender(class_332 graphics, float tickDelta) {
        if (!showHUD) return;
        
        class_310 mc = class_310.method_1551();
        
        if (mc.field_1724 == null || !CultivationDataCache.hasCachedData()) {
            return;
        }
        
        CultivationData data = CultivationDataCache.getCachedData();
        CultivationRealm realm = data.getRealm();
        int currentExp = data.getCurrentExp();
        int spiritualPower = data.getSpiritualPower();
        int maxSpiritualPower = data.getMaxSpiritualPower();
        String rootName = data.getSpiritualRoot().getDisplayName();
        
        int x = mc.method_22683().method_4486() - 160;
        int y = 10;
        
        graphics.method_51439(mc.field_1772, class_2561.method_43470("境界: " + realm.getDisplayName()), x, y, 0xFFFFFF, true);
        y += 12;
        
        graphics.method_51439(mc.field_1772, class_2561.method_43470("灵根: " + rootName), x, y, 0xFFFFFF, true);
        y += 12;
        
        graphics.method_51439(mc.field_1772, class_2561.method_43470("经验: " + currentExp), x, y, 0xFFFFFF, true);
        y += 12;
        
        graphics.method_51439(mc.field_1772, class_2561.method_43470("灵力: " + spiritualPower + "/" + maxSpiritualPower), x, y, 0xFFFFFF, true);
        y += 12;
        
        int barWidth = 140;
        int barHeight = 6;
        float powerRatio = data.getSpiritualPowerRatio();
        
        graphics.method_25294(x, y, x + barWidth, y + barHeight, 0x80000000);
        graphics.method_25294(x, y, x + (int)(barWidth * powerRatio), y + barHeight, 0x80FFFFFF);
    }
}