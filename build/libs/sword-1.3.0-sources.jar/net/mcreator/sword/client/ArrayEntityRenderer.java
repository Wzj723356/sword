package net.mcreator.sword.client;

import net.minecraft.class_2960;
import net.minecraft.class_5617;
import net.minecraft.class_897;

public class ArrayEntityRenderer extends class_897<net.mcreator.sword.entity.ArrayEntity> {
    
    public ArrayEntityRenderer(class_5617.class_5618 context) {
        super(context);
    }
    
    @Override
    public class_2960 getTextureLocation(net.mcreator.sword.entity.ArrayEntity entity) {
        return null;
    }
}