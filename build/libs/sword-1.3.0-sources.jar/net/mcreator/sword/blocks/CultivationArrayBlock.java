package net.mcreator.sword.blocks;

import net.mcreator.sword.cultivation.CultivationManager;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2398;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_3218;

public class CultivationArrayBlock extends class_2248 {
    public CultivationArrayBlock() {
        super(class_2248.Properties.method_9637().method_9629(2.0F, 6.0F).method_9631(state -> 8).method_9634().method_22488());
    }

    @Override
    public class_1269 method_9534(class_2680 state, class_1937 level, class_2338 pos, class_1657 player, class_1268 hand, net.minecraft.class_3965 hit) {
        if (!level.field_9236) {
            CultivationManager.addExperience(player, 50);
            
            if (CultivationManager.checkLevelUp(player)) {
                player.method_7353(class_2561.method_43470("阵法修炼！境界提升！当前境界：" + CultivationManager.getCultivationData(player).getRealm().getDisplayName()), true);
            } else {
                player.method_7353(class_2561.method_43470("阵法修炼！获得50点修仙经验"), true);
            }
            
            if (player instanceof net.minecraft.class_3222 serverPlayer) {
                CultivationManager.syncToClient(serverPlayer);
            }
            
            if (level instanceof class_3218 serverLevel) {
                for (int i = 0; i < 80; i++) {
                    double angle = i * Math.PI * 2 / 80;
                    double radius = 2.0;
                    double x = pos.method_10263() + 0.5 + Math.cos(angle) * radius;
                    double z = pos.method_10260() + 0.5 + Math.sin(angle) * radius;
                    
                    serverLevel.method_14199(class_2398.field_11207,
                        x, pos.method_10264() + 0.5, z,
                        1, 0, 0.05, 0, 0.02);
                }
                
                for (int i = 0; i < 30; i++) {
                    serverLevel.method_14199(class_2398.field_11215,
                        pos.method_10263() + 0.5 + (level.field_9229.method_43058() - 0.5) * 3.0,
                        pos.method_10264() + 0.5 + level.field_9229.method_43058() * 2.0,
                        pos.method_10260() + 0.5 + (level.field_9229.method_43058() - 0.5) * 3.0,
                        1, 0, 0.1, 0, 0);
                }
            }
        }
        
        return class_1269.field_5812;
    }

    @Override
    public void method_9496(class_2680 state, class_1937 level, class_2338 pos, net.minecraft.class_5819 random) {
        if (level.field_9236) {
            for (int i = 0; i < 3; i++) {
                double angle = random.method_43058() * Math.PI * 2;
                double radius = 1.0 + random.method_43058() * 1.5;
                double x = pos.method_10263() + 0.5 + Math.cos(angle) * radius;
                double z = pos.method_10260() + 0.5 + Math.sin(angle) * radius;
                
                level.method_8406(class_2398.field_11207, x, pos.method_10264() + 0.5, z, 0, 0.03, 0);
            }
            
            for (int i = 0; i < 2; i++) {
                double x = pos.method_10263() + 0.5 + (random.method_43058() - 0.5) * 1.0;
                double y = pos.method_10264() + 0.1 + random.method_43058() * 0.5;
                double z = pos.method_10260() + 0.5 + (random.method_43058() - 0.5) * 1.0;
                
                level.method_8406(class_2398.field_11215, x, y, z, 0, 0.02, 0);
            }
        }
    }
}
