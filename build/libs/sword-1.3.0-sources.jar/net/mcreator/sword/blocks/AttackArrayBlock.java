package net.mcreator.sword.blocks;

import java.util.List;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1588;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_2398;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_3218;

public class AttackArrayBlock extends class_2248 {
    public AttackArrayBlock() {
        super(class_2248.Properties.method_9637().method_9629(2.5F, 7.0F).method_9631(state -> 8).method_9634().method_22488());
    }

    @Override
    public class_1269 method_9534(class_2680 state, class_1937 level, class_2338 pos, class_1657 player, class_1268 hand, net.minecraft.class_3965 hit) {
        if (!level.field_9236) {
            class_238 searchBox = new class_238(pos).method_1014(10.0);
            List<class_1588> enemies = level.method_18467(class_1588.class, searchBox);
            
            int damageCount = 0;
            for (class_1588 enemy : enemies) {
                enemy.method_5643(level.method_48963().method_48802(player), 20.0F);
                damageCount++;
                
                if (level instanceof class_3218 serverLevel) {
                    for (int i = 0; i < 10; i++) {
                        serverLevel.method_14199(class_2398.field_11216,
                            enemy.method_23317(),
                            enemy.method_23318() + enemy.method_17682() / 2,
                            enemy.method_23321(),
                            1, 0, 0, 0, 0.05);
                    }
                }
            }
            
            player.method_7353(class_2561.method_43470("攻击法阵发动！对" + damageCount + "个敌人造成伤害"), true);
            
            if (level instanceof class_3218 serverLevel) {
                for (int i = 0; i < 100; i++) {
                    double angle = i * Math.PI * 2 / 100;
                    double radius = 3.0;
                    double x = pos.method_10263() + 0.5 + Math.cos(angle) * radius;
                    double z = pos.method_10260() + 0.5 + Math.sin(angle) * radius;
                    
                    serverLevel.method_14199(class_2398.field_11240,
                        x, pos.method_10264() + 0.5, z,
                        1, 0, 0.1, 0, 0.02);
                }
            }
        }
        
        return class_1269.field_5812;
    }

    @Override
    public void method_9496(class_2680 state, class_1937 level, class_2338 pos, net.minecraft.class_5819 random) {
        if (level.field_9236) {
            for (int i = 0; i < 5; i++) {
                double angle = random.method_43058() * Math.PI * 2;
                double radius = 1.0 + random.method_43058() * 2.0;
                double x = pos.method_10263() + 0.5 + Math.cos(angle) * radius;
                double z = pos.method_10260() + 0.5 + Math.sin(angle) * radius;
                
                level.method_8406(class_2398.field_11240, x, pos.method_10264() + 0.5, z, 0, 0.05, 0);
            }
            
            for (int i = 0; i < 3; i++) {
                double x = pos.method_10263() + 0.5 + (random.method_43058() - 0.5) * 1.0;
                double y = pos.method_10264() + 0.1 + random.method_43058() * 0.5;
                double z = pos.method_10260() + 0.5 + (random.method_43058() - 0.5) * 1.0;
                
                level.method_8406(class_2398.field_11251, x, y, z, 0, 0.02, 0);
            }
        }
    }
}