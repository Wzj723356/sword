package net.mcreator.sword.blocks;

import java.util.List;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_2398;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_3218;

public class HealingArrayBlock extends class_2248 {
    public HealingArrayBlock() {
        super(class_2248.Properties.method_9637().method_9629(2.0F, 6.0F).method_9631(state -> 12).method_9634().method_22488());
    }

    @Override
    public class_1269 method_9534(class_2680 state, class_1937 level, class_2338 pos, class_1657 player, class_1268 hand, net.minecraft.class_3965 hit) {
        if (!level.field_9236) {
            class_238 searchBox = new class_238(pos).method_1014(15.0);
            List<class_1309> entities = level.method_18467(class_1309.class, searchBox);
            
            int healCount = 0;
            for (class_1309 entity : entities) {
                entity.method_6025(20.0F);
                entity.method_6092(new class_1293(class_1294.field_5924, 300, 2, false, false));
                healCount++;
                
                if (level instanceof class_3218 serverLevel) {
                    for (int i = 0; i < 15; i++) {
                        serverLevel.method_14199(class_2398.field_11201,
                            entity.method_23317() + (level.field_9229.method_43058() - 0.5) * 1.0,
                            entity.method_23318() + entity.method_17682() + 0.5,
                            entity.method_23321() + (level.field_9229.method_43058() - 0.5) * 1.0,
                            1, 0, 0.1, 0, 0);
                    }
                }
            }
            
            player.method_7353(class_2561.method_43470("治疗法阵发动！治疗了" + healCount + "个生物"), true);
            
            if (level instanceof class_3218 serverLevel) {
                for (int i = 0; i < 50; i++) {
                    double angle = i * Math.PI * 2 / 50;
                    double radius = 2.5;
                    double x = pos.method_10263() + 0.5 + Math.cos(angle) * radius;
                    double z = pos.method_10260() + 0.5 + Math.sin(angle) * radius;
                    
                    serverLevel.method_14199(class_2398.field_11201,
                        x, pos.method_10264() + 0.5, z,
                        1, 0, 0.05, 0, 0);
                }
            }
        }
        
        return class_1269.field_5812;
    }

    @Override
    public void method_9496(class_2680 state, class_1937 level, class_2338 pos, net.minecraft.class_5819 random) {
        if (level.field_9236) {
            for (int i = 0; i < 4; i++) {
                double angle = random.method_43058() * Math.PI * 2;
                double radius = 0.5 + random.method_43058() * 1.5;
                double x = pos.method_10263() + 0.5 + Math.cos(angle) * radius;
                double z = pos.method_10260() + 0.5 + Math.sin(angle) * radius;
                
                level.method_8406(class_2398.field_11201, x, pos.method_10264() + 0.5, z, 0, 0.05, 0);
            }
            
            for (int i = 0; i < 3; i++) {
                double x = pos.method_10263() + 0.5 + (random.method_43058() - 0.5) * 1.5;
                double y = pos.method_10264() + 0.1 + random.method_43058() * 0.5;
                double z = pos.method_10260() + 0.5 + (random.method_43058() - 0.5) * 1.5;
                
                level.method_8406(class_2398.field_11220, x, y, z, 0, 0.02, 0);
            }
        }
    }
}