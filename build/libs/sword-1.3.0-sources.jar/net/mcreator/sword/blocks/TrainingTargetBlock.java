package net.mcreator.sword.blocks;

import net.mcreator.sword.items.CultivationSword;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.mcreator.sword.items.CultivationBlade;
import net.mcreator.sword.items.CultivationSpear;
import net.mcreator.sword.cultivation.CultivationManager;

public class TrainingTargetBlock extends class_2248 {
    public TrainingTargetBlock() {
        super(class_2248.Properties.method_9637().method_9629(2.0F, 6.0F));
    }

    @Override
    public class_1269 method_9534(class_2680 state, class_1937 level, class_2338 pos, class_1657 player, class_1268 hand, net.minecraft.class_3965 hit) {
        class_1799 heldItem = player.method_5998(hand);
        
        if (!level.field_9236) {
            boolean isWeapon = heldItem.method_7909() instanceof CultivationSword || 
                              heldItem.method_7909() instanceof CultivationBlade || 
                              heldItem.method_7909() instanceof CultivationSpear;
            
            if (isWeapon) {
                CultivationManager.addExperience(player, 20);
                player.method_7353(class_2561.method_43470("功法训练！获得20点修仙经验"), true);
                return class_1269.field_5812;
            } else {
                player.method_7353(class_2561.method_43470("需要手持修仙武器才能训练"), true);
                return class_1269.field_5814;
            }
        }
        
        return class_1269.field_5812;
    }
}
