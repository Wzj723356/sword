package net.mcreator.sword.blocks;

import java.util.List;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_2398;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_3218;

public class TeleportArrayBlock extends class_2248 {
    public TeleportArrayBlock() {
        super(class_2248.Properties.method_9637().method_9629(3.0F, 8.0F).method_9631(state -> 10).method_9634().method_22488());
    }

    @Override
    public class_1269 method_9534(class_2680 state, class_1937 level, class_2338 pos, class_1657 player, class_1268 hand, net.minecraft.class_3965 hit) {
        if (!level.field_9236) {
            class_238 searchBox = new class_238(pos).method_1014(50.0);
            List<class_2338> teleportArrays = new java.util.ArrayList<>();
            
            for (class_2338 checkPos : class_2338.method_10097(
                new class_2338(pos.method_10263() - 50, pos.method_10264() - 50, pos.method_10260() - 50),
                new class_2338(pos.method_10263() + 50, pos.method_10264() + 50, pos.method_10260() + 50)
            )) {
                if (level.method_8320(checkPos).method_26204() instanceof TeleportArrayBlock && !checkPos.equals(pos)) {
                    teleportArrays.add(checkPos);
                }
            }
            
            if (teleportArrays.isEmpty()) {
                player.method_7353(class_2561.method_43470("没有找到其他传送阵！"), true);
            } else {
                class_2338 targetPos = teleportArrays.get(player.method_6051().method_43048(teleportArrays.size()));
                player.method_5859(targetPos.method_10263() + 0.5, targetPos.method_10264() + 1.0, targetPos.method_10260() + 0.5);
                player.method_7353(class_2561.method_43470("传送成功！"), true);
                
                if (level instanceof class_3218 serverLevel) {
                    for (int i = 0; i < 50; i++) {
                        serverLevel.method_14199(class_2398.field_11214, 
                            targetPos.method_10263() + 0.5 + (level.field_9229.method_43058() - 0.5) * 2,
                            targetPos.method_10264() + 1.0 + level.field_9229.method_43058() * 2,
                            targetPos.method_10260() + 0.5 + (level.field_9229.method_43058() - 0.5) * 2,
                            1, 0, 0, 0, 0);
                    }
                }
            }
        }
        
        return class_1269.field_5812;
    }

    @Override
    public void method_9496(class_2680 state, class_1937 level, class_2338 pos, net.minecraft.class_5819 random) {
        if (level.field_9236) {
            for (int i = 0; i < 3; i++) {
                double x = pos.method_10263() + 0.5 + (random.method_43058() - 0.5) * 1.5;
                double y = pos.method_10264() + 0.1 + random.method_43058() * 0.3;
                double z = pos.method_10260() + 0.5 + (random.method_43058() - 0.5) * 1.5;
                
                level.method_8406(class_2398.field_11214, x, y, z, 0, 0.1, 0);
            }
            
            for (int i = 0; i < 2; i++) {
                double angle = random.method_43058() * Math.PI * 2;
                double radius = 0.8 + random.method_43058() * 0.2;
                double x = pos.method_10263() + 0.5 + Math.cos(angle) * radius;
                double z = pos.method_10260() + 0.5 + Math.sin(angle) * radius;
                
                level.method_8406(class_2398.field_11207, x, pos.method_10264() + 0.2, z, 0, 0.05, 0);
            }
        }
    }
}