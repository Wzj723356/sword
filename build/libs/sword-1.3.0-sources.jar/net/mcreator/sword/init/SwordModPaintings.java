/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.sword.init;

import net.mcreator.sword.SwordMod;
import net.minecraft.class_1535;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_7923;

public class SwordModPaintings {
	public static void load() {
		class_2378.method_10230(class_7923.field_41182, new class_2960(SwordMod.MODID, "ffdsf"), new class_1535(32, 32));
	}
}