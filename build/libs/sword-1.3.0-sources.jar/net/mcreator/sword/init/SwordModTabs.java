/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.sword.init;

import net.mcreator.sword.SwordMod;
import net.mcreator.sword.init.SwordModItems;
import net.minecraft.class_1761;
import net.minecraft.class_1799;
import net.minecraft.class_2378;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_7923;
import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;

public class SwordModTabs {
	public static class_1761 TAB_SHEN;

	public static void load() {
		TAB_SHEN = class_2378.method_10230(class_7923.field_44687, new class_2960(SwordMod.MODID, "shen"), 
				FabricItemGroup.builder()
						.method_47321(class_2561.method_43471("item_group." + SwordMod.MODID + ".shen"))
						.method_47320(() -> new class_1799(SwordModItems.DAVO))
						.method_47317((parameters, entries) -> {
							entries.method_45421(SwordModItems.DAVO);
							entries.method_45421(SwordModItems.DDSA);
							entries.method_45421(SwordModItems.DAVO_HELMET);
							entries.method_45421(SwordModItems.DAVO_CHESTPLATE);
							entries.method_45421(SwordModItems.DAVO_LEGGINGS);
							entries.method_45421(SwordModItems.DAVO_BOOTS);
							entries.method_45421(SwordModItems.DAVO_SHIELD);
							entries.method_45421(SwordModItems.CULTIVATION_STAFF);
							entries.method_45421(SwordModItems.CULTIVATION_ARRAY_ITEM);
							entries.method_45421(SwordModItems.TELEPORT_ARRAY_ITEM);
							entries.method_45421(SwordModItems.ATTACK_ARRAY_ITEM);
							entries.method_45421(SwordModItems.HEALING_ARRAY_ITEM);
							entries.method_45421(SwordModItems.TRANSCENDENT_BREAK_WAND);
							entries.method_45421(SwordModItems.TRANSCENDENT_DETECT_WAND);
							entries.method_45421(SwordModItems.TRANSCENDENT_SEAL_WAND);
							entries.method_45421(SwordModItems.CULTIVATION_SWORD);
							entries.method_45421(SwordModItems.CULTIVATION_BLADE);
							entries.method_45421(SwordModItems.CULTIVATION_SPEAR);
							entries.method_45421(SwordModItems.LOW_GRADE_SPIRIT_STONE);
							entries.method_45421(SwordModItems.MEDIUM_GRADE_SPIRIT_STONE);
							entries.method_45421(SwordModItems.HIGH_GRADE_SPIRIT_STONE);
							entries.method_45421(SwordModItems.SUPREME_SPIRIT_STONE);
							entries.method_45421(SwordModItems.HEALING_PILL);
							entries.method_45421(SwordModItems.SPIRIT_GATHERING_PILL);
							entries.method_45421(SwordModItems.FOUNDATION_PILL);
							entries.method_45421(SwordModItems.SPIRITUAL_ROOT_REFORGING_PILL);
							entries.method_45421(SwordModItems.FLYING_SWORD);
							entries.method_45421(SwordModItems.TRAINING_TARGET);
							entries.method_45421(SwordModItems.CLOUD_BOAT);
							entries.method_45421(SwordModItems.ATTACK_TALISMAN);
							entries.method_45421(SwordModItems.DEFENSE_TALISMAN);
							entries.method_45421(SwordModItems.HEALING_TALISMAN);
							entries.method_45421(SwordModItems.LIGHTNING_TALISMAN);
							entries.method_45421(SwordModItems.FIRE_TALISMAN);
							entries.method_45421(SwordModItems.ICE_TALISMAN);
							entries.method_45421(SwordModItems.WIND_TALISMAN);
							entries.method_45421(SwordModItems.TELEPORT_TALISMAN);
						})
						.method_47324());
	}
}