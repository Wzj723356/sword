/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.sword.init;

import net.mcreator.sword.SwordMod;
import net.mcreator.sword.entity.CloudBoatEntity;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1311;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_7923;
import net.mcreator.sword.entity.ArrayEntity;

public class SwordModEntities {
    public static class_1299<CloudBoatEntity> CLOUD_BOAT;
    public static class_1299<ArrayEntity> ARRAY;

    public static void load() {
        CLOUD_BOAT = register("cloud_boat", 
            class_1299.class_1300.<CloudBoatEntity>method_5903(CloudBoatEntity::new, class_1311.field_17715)
                .method_17687(1.375F, 0.5625F)
                .method_27299(10)
                .method_5905("cloud_boat"));
        ARRAY = register("array", 
            class_1299.class_1300.<ArrayEntity>method_5903(ArrayEntity::new, class_1311.field_17715)
                .method_17687(0.0F, 0.0F)
                .method_27299(64)
                .method_19947()
                .method_5905("array"));
    }

    private static <T extends class_1297> class_1299<T> register(String registryName, class_1299<T> entityType) {
        return class_2378.method_10230(class_7923.field_41177, new class_2960(SwordMod.MODID, registryName), entityType);
    }
}