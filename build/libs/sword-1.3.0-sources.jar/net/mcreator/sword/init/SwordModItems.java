/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.sword.init;

import net.mcreator.sword.SwordMod;
import net.mcreator.sword.DavoItem;
import net.mcreator.sword.DdsaItem;
import net.mcreator.sword.DavoHelmet;
import net.mcreator.sword.DavoChestplate;
import net.mcreator.sword.DavoLeggings;
import net.mcreator.sword.DavoBoots;
import net.mcreator.sword.DavoShield;
import net.mcreator.sword.items.CultivationStaff;
import net.mcreator.sword.init.SwordModBlocks;
import net.mcreator.sword.items.CultivationSword;
import net.mcreator.sword.items.CultivationBlade;
import net.mcreator.sword.items.CultivationSpear;
import net.mcreator.sword.items.LowGradeSpiritStone;
import net.mcreator.sword.items.MediumGradeSpiritStone;
import net.mcreator.sword.items.HighGradeSpiritStone;
import net.mcreator.sword.items.SupremeSpiritStone;
import net.mcreator.sword.items.HealingPill;
import net.mcreator.sword.items.SpiritGatheringPill;
import net.mcreator.sword.items.FoundationPill;
import net.mcreator.sword.items.SpiritualRootReforgingPill;
import net.mcreator.sword.items.FlyingSword;
import net.mcreator.sword.items.CloudBoatItem;
import net.mcreator.sword.items.TalismanPaper;
import net.minecraft.class_1747;
import net.minecraft.class_1792;
import net.minecraft.class_1802;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_5272;
import net.minecraft.class_6395;
import net.minecraft.class_7923;
import net.mcreator.sword.items.ArrayItem;
import net.mcreator.sword.items.MagicWandItem;
import net.mcreator.sword.items.SkillBook;
import net.mcreator.sword.cultivation.CultivationTechnique;

public class SwordModItems {
	public static class_1792 DAVO;
	public static class_1792 DDSA;
	public static class_1792 DAVO_HELMET;
	public static class_1792 DAVO_CHESTPLATE;
	public static class_1792 DAVO_LEGGINGS;
	public static class_1792 DAVO_BOOTS;
	public static class_1792 DAVO_SHIELD;
	public static class_1792 CULTIVATION_STAFF;
	public static class_1792 CULTIVATION_ARRAY;
	public static class_1792 CULTIVATION_SWORD;
	public static class_1792 CULTIVATION_BLADE;
	public static class_1792 CULTIVATION_SPEAR;
	public static class_1792 LOW_GRADE_SPIRIT_STONE;
	public static class_1792 MEDIUM_GRADE_SPIRIT_STONE;
	public static class_1792 HIGH_GRADE_SPIRIT_STONE;
	public static class_1792 SUPREME_SPIRIT_STONE;
	public static class_1792 HEALING_PILL;
	public static class_1792 SPIRIT_GATHERING_PILL;
	public static class_1792 FOUNDATION_PILL;
	public static class_1792 SPIRITUAL_ROOT_REFORGING_PILL;
	public static class_1792 FLYING_SWORD;
	public static class_1792 TRAINING_TARGET;
	public static class_1792 CLOUD_BOAT;
	public static class_1792 CULTIVATION_ARRAY_ITEM;
	public static class_1792 TELEPORT_ARRAY_ITEM;
	public static class_1792 ATTACK_ARRAY_ITEM;
	public static class_1792 HEALING_ARRAY_ITEM;
	public static class_1792 TRANSCENDENT_BREAK_WAND;
	public static class_1792 TRANSCENDENT_DETECT_WAND;
	public static class_1792 TRANSCENDENT_SEAL_WAND;
	public static class_1792 ATTACK_TALISMAN;
	public static class_1792 DEFENSE_TALISMAN;
	public static class_1792 HEALING_TALISMAN;
	public static class_1792 LIGHTNING_TALISMAN;
	public static class_1792 FIRE_TALISMAN;
	public static class_1792 ICE_TALISMAN;
	public static class_1792 WIND_TALISMAN;
	public static class_1792 TELEPORT_TALISMAN;
	
	// 技能书（主动技能）
	public static class_1792 FIRE_BALL_BOOK;
	public static class_1792 ICE_SHARD_BOOK;
	public static class_1792 LIGHTNING_BOLT_BOOK;
	public static class_1792 WIND_BLADE_BOOK;
	public static class_1792 EARTH_SPIKE_BOOK;
	public static class_1792 HEALING_LIGHT_BOOK;
	public static class_1792 SHIELD_BARRIER_BOOK;
	public static class_1792 TELEPORT_BOOK;
	public static class_1792 FLYING_SWORD_BOOK;
	public static class_1792 ELEMENTAL_BURST_BOOK;
	public static class_1792 SPIRITUAL_AURA_BOOK;
	public static class_1792 BODY_FORTIFICATION_BOOK;
	public static class_1792 SOUL_RESONANCE_BOOK;
	public static class_1792 TIME_DILATION_BOOK;
	
	// 功法书（被动功法）
	public static class_1792 SWORD_BASIC_BOOK;
	public static class_1792 SWORD_INTERMEDIATE_BOOK;
	public static class_1792 SWORD_ADVANCED_BOOK;
	public static class_1792 SWORD_MASTER_BOOK;
	public static class_1792 BLADE_BASIC_BOOK;
	public static class_1792 BLADE_INTERMEDIATE_BOOK;
	public static class_1792 BLADE_ADVANCED_BOOK;
	public static class_1792 BLADE_MASTER_BOOK;
	public static class_1792 SPEAR_BASIC_BOOK;
	public static class_1792 SPEAR_INTERMEDIATE_BOOK;
	public static class_1792 SPEAR_ADVANCED_BOOK;
	public static class_1792 SPEAR_MASTER_BOOK;

	public static void load() {
		DAVO = register("davo", new DavoItem());
		DDSA = register("ddsa", new DdsaItem());
		DAVO_HELMET = register("davo_helmet", new DavoHelmet());
		DAVO_CHESTPLATE = register("davo_chestplate", new DavoChestplate());
		DAVO_LEGGINGS = register("davo_leggings", new DavoLeggings());
		DAVO_BOOTS = register("davo_boots", new DavoBoots());
		DAVO_SHIELD = register("davo_shield", new DavoShield());
		CULTIVATION_STAFF = register("cultivation_staff", new CultivationStaff());
		CULTIVATION_ARRAY = register("cultivation_array", new class_1747(SwordModBlocks.CULTIVATION_ARRAY, new class_1792.class_1793()));
		CULTIVATION_SWORD = register("cultivation_sword", new CultivationSword());
		CULTIVATION_BLADE = register("cultivation_blade", new CultivationBlade());
		CULTIVATION_SPEAR = register("cultivation_spear", new CultivationSpear());
		LOW_GRADE_SPIRIT_STONE = register("low_grade_spirit_stone", new LowGradeSpiritStone());
		MEDIUM_GRADE_SPIRIT_STONE = register("medium_grade_spirit_stone", new MediumGradeSpiritStone());
		HIGH_GRADE_SPIRIT_STONE = register("high_grade_spirit_stone", new HighGradeSpiritStone());
		SUPREME_SPIRIT_STONE = register("supreme_spirit_stone", new SupremeSpiritStone());
		HEALING_PILL = register("healing_pill", new HealingPill());
		SPIRIT_GATHERING_PILL = register("spirit_gathering_pill", new SpiritGatheringPill());
		FOUNDATION_PILL = register("foundation_pill", new FoundationPill());
		SPIRITUAL_ROOT_REFORGING_PILL = register("spiritual_root_reforging_pill", new SpiritualRootReforgingPill());
		FLYING_SWORD = register("flying_sword", new FlyingSword());
		TRAINING_TARGET = register("training_target", new class_1747(SwordModBlocks.TRAINING_TARGET, new class_1792.class_1793()));
		CLOUD_BOAT = register("cloud_boat", new CloudBoatItem());
		CULTIVATION_ARRAY_ITEM = register("cultivation_array_item", new ArrayItem("cultivation", new class_1792.class_1793()));
		TELEPORT_ARRAY_ITEM = register("teleport_array_item", new ArrayItem("teleport", new class_1792.class_1793()));
		ATTACK_ARRAY_ITEM = register("attack_array_item", new ArrayItem("attack", new class_1792.class_1793()));
		HEALING_ARRAY_ITEM = register("healing_array_item", new ArrayItem("healing", new class_1792.class_1793()));
		TRANSCENDENT_BREAK_WAND = register("transcendent_break_wand", new MagicWandItem("break", new class_1792.class_1793().method_7889(1).method_7895(1)));
		TRANSCENDENT_DETECT_WAND = register("transcendent_detect_wand", new MagicWandItem("detect", new class_1792.class_1793().method_7889(1).method_7895(1)));
		TRANSCENDENT_SEAL_WAND = register("transcendent_seal_wand", new MagicWandItem("seal", new class_1792.class_1793().method_7889(1).method_7895(1)));
		ATTACK_TALISMAN = register("attack_talisman", new TalismanPaper(TalismanPaper.TalismanType.ATTACK));
		DEFENSE_TALISMAN = register("defense_talisman", new TalismanPaper(TalismanPaper.TalismanType.DEFENSE));
		HEALING_TALISMAN = register("healing_talisman", new TalismanPaper(TalismanPaper.TalismanType.HEALING));
		LIGHTNING_TALISMAN = register("lightning_talisman", new TalismanPaper(TalismanPaper.TalismanType.LIGHTNING));
		FIRE_TALISMAN = register("fire_talisman", new TalismanPaper(TalismanPaper.TalismanType.FIRE));
		ICE_TALISMAN = register("ice_talisman", new TalismanPaper(TalismanPaper.TalismanType.ICE));
		WIND_TALISMAN = register("wind_talisman", new TalismanPaper(TalismanPaper.TalismanType.WIND));
		TELEPORT_TALISMAN = register("teleport_talisman", new TalismanPaper(TalismanPaper.TalismanType.TELEPORT));
		
		// 注册技能书（主动技能）
		FIRE_BALL_BOOK = register("fire_ball_book", new SkillBook(CultivationTechnique.FIRE_BALL));
		ICE_SHARD_BOOK = register("ice_shard_book", new SkillBook(CultivationTechnique.ICE_SHARD));
		LIGHTNING_BOLT_BOOK = register("lightning_bolt_book", new SkillBook(CultivationTechnique.LIGHTNING_BOLT));
		WIND_BLADE_BOOK = register("wind_blade_book", new SkillBook(CultivationTechnique.WIND_BLADE));
		EARTH_SPIKE_BOOK = register("earth_spike_book", new SkillBook(CultivationTechnique.EARTH_SPIKE));
		HEALING_LIGHT_BOOK = register("healing_light_book", new SkillBook(CultivationTechnique.HEALING_LIGHT));
		SHIELD_BARRIER_BOOK = register("shield_barrier_book", new SkillBook(CultivationTechnique.SHIELD_BARRIER));
		TELEPORT_BOOK = register("teleport_book", new SkillBook(CultivationTechnique.TELEPORT));
		FLYING_SWORD_BOOK = register("flying_sword_book", new SkillBook(CultivationTechnique.FLYING_SWORD));
		ELEMENTAL_BURST_BOOK = register("elemental_burst_book", new SkillBook(CultivationTechnique.ELEMENTAL_BURST));
		SPIRITUAL_AURA_BOOK = register("spiritual_aura_book", new SkillBook(CultivationTechnique.SPIRITUAL_AURA));
		BODY_FORTIFICATION_BOOK = register("body_fortification_book", new SkillBook(CultivationTechnique.BODY_FORTIFICATION));
		SOUL_RESONANCE_BOOK = register("soul_resonance_book", new SkillBook(CultivationTechnique.SOUL_RESONANCE));
		TIME_DILATION_BOOK = register("time_dilation_book", new SkillBook(CultivationTechnique.TIME_DILATION));
		
		// 注册功法书（被动功法）
		SWORD_BASIC_BOOK = register("sword_basic_book", new SkillBook(CultivationTechnique.SWORD_BASIC));
		SWORD_INTERMEDIATE_BOOK = register("sword_intermediate_book", new SkillBook(CultivationTechnique.SWORD_INTERMEDIATE));
		SWORD_ADVANCED_BOOK = register("sword_advanced_book", new SkillBook(CultivationTechnique.SWORD_ADVANCED));
		SWORD_MASTER_BOOK = register("sword_master_book", new SkillBook(CultivationTechnique.SWORD_MASTER));
		BLADE_BASIC_BOOK = register("blade_basic_book", new SkillBook(CultivationTechnique.BLADE_BASIC));
		BLADE_INTERMEDIATE_BOOK = register("blade_intermediate_book", new SkillBook(CultivationTechnique.BLADE_INTERMEDIATE));
		BLADE_ADVANCED_BOOK = register("blade_advanced_book", new SkillBook(CultivationTechnique.BLADE_ADVANCED));
		BLADE_MASTER_BOOK = register("blade_master_book", new SkillBook(CultivationTechnique.BLADE_MASTER));
		SPEAR_BASIC_BOOK = register("spear_basic_book", new SkillBook(CultivationTechnique.SPEAR_BASIC));
		SPEAR_INTERMEDIATE_BOOK = register("spear_intermediate_book", new SkillBook(CultivationTechnique.SPEAR_INTERMEDIATE));
		SPEAR_ADVANCED_BOOK = register("spear_advanced_book", new SkillBook(CultivationTechnique.SPEAR_ADVANCED));
		SPEAR_MASTER_BOOK = register("spear_master_book", new SkillBook(CultivationTechnique.SPEAR_MASTER));
	}

	public static void clientLoad() {
	}

	private static class_1792 register(String registryName, class_1792 item) {
		return class_2378.method_10230(class_7923.field_41178, new class_2960(SwordMod.MODID, registryName), item);
	}

	private static void registerBlockingProperty(class_1792 item) {
		class_5272.method_27879(item, new class_2960("blocking"), (class_6395) class_5272.method_27878(class_1802.field_8255, new class_2960("blocking")));
		class_5272.method_27879(item, new class_2960("blocking"), (class_6395) class_5272.method_27878(class_1802.field_8255, new class_2960("blocking")));
	}
}