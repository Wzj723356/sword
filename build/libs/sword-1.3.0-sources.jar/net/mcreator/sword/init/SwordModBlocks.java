/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.sword.init;

import net.mcreator.sword.SwordMod;
import net.mcreator.sword.blocks.CultivationArrayBlock;
import net.mcreator.sword.blocks.TrainingTargetBlock;
import net.minecraft.class_2248;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_7923;
import net.mcreator.sword.blocks.TeleportArrayBlock;
import net.mcreator.sword.blocks.AttackArrayBlock;
import net.mcreator.sword.blocks.HealingArrayBlock;

public class SwordModBlocks {
	public static class_2248 CULTIVATION_ARRAY;
	public static class_2248 TRAINING_TARGET;
	public static class_2248 TELEPORT_ARRAY;
	public static class_2248 ATTACK_ARRAY;
	public static class_2248 HEALING_ARRAY;

	public static void load() {
		CULTIVATION_ARRAY = register("cultivation_array", new CultivationArrayBlock());
		TRAINING_TARGET = register("training_target", new TrainingTargetBlock());
		TELEPORT_ARRAY = register("teleport_array", new TeleportArrayBlock());
		ATTACK_ARRAY = register("attack_array", new AttackArrayBlock());
		HEALING_ARRAY = register("healing_array", new HealingArrayBlock());
	}

	private static class_2248 register(String registryName, class_2248 block) {
		return class_2378.method_10230(class_7923.field_41175, new class_2960(SwordMod.MODID, registryName), block);
	}
}
