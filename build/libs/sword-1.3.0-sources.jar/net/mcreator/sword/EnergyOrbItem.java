package net.mcreator.sword;

import java.util.List;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1814;
import net.minecraft.class_1836;
import net.minecraft.class_1937;
import net.minecraft.class_2561;

public class EnergyOrbItem extends class_1792 {
    public EnergyOrbItem() {
        super(new class_1792.class_1793()
                .method_24359()
                .method_7894(class_1814.field_8904)
                .method_7889(64));
    }

    public EnergyOrbItem(class_1792.class_1793 properties) {
        super(properties
                .method_24359()
                .method_7894(class_1814.field_8904)
                .method_7889(64));
    }

    @Override
    public void method_7851(class_1799 itemstack, class_1937 world, List<class_2561> list, class_1836 flag) {
        super.method_7851(itemstack, world, list, flag);
        list.add(class_2561.method_43470("蕴含强大能量的球体"));
        list.add(class_2561.method_43470("用于合成范围攻击神剑"));
    }

    public class_1814 method_7862(class_1799 itemstack) {
        return class_1814.field_8904;
    }
}