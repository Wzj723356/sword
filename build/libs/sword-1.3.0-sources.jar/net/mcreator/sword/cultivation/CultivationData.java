package net.mcreator.sword.cultivation;

import java.util.HashSet;
import java.util.Set;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2519;

public class CultivationData {
    private CultivationRealm realm;
    private int currentExp;
    private SpiritualRoot spiritualRoot;
    private boolean hasStartedCultivation;
    private int spiritualPower;
    private int maxSpiritualPower;
    private CultivationTechnique technique;
    private Set<String> learnedSkills;

    public CultivationData() {
        this.realm = CultivationRealm.MORTAL;
        this.currentExp = 0;
        this.spiritualRoot = SpiritualRoot.NONE;
        this.hasStartedCultivation = false;
        this.maxSpiritualPower = 100;
        this.spiritualPower = 0;
        this.technique = CultivationTechnique.NONE;
        this.learnedSkills = new HashSet<>();
    }

    public CultivationRealm getRealm() {
        return realm;
    }

    public void setRealm(CultivationRealm realm) {
        this.realm = realm;
    }

    public int getCurrentExp() {
        return currentExp;
    }

    public void setCurrentExp(int currentExp) {
        this.currentExp = currentExp;
    }

    public SpiritualRoot getSpiritualRoot() {
        return spiritualRoot;
    }

    public void setSpiritualRoot(SpiritualRoot spiritualRoot) {
        this.spiritualRoot = spiritualRoot;
    }

    public boolean hasStartedCultivation() {
        return hasStartedCultivation;
    }

    public void setHasStartedCultivation(boolean hasStartedCultivation) {
        this.hasStartedCultivation = hasStartedCultivation;
    }

    public int getSpiritualPower() {
        return spiritualPower;
    }

    public void setSpiritualPower(int spiritualPower) {
        this.spiritualPower = Math.min(spiritualPower, maxSpiritualPower);
    }

    public int getMaxSpiritualPower() {
        return maxSpiritualPower;
    }

    public void setMaxSpiritualPower(int maxSpiritualPower) {
        this.maxSpiritualPower = maxSpiritualPower;
        this.spiritualPower = Math.min(spiritualPower, maxSpiritualPower);
    }

    public void addSpiritualPower(int amount) {
        this.spiritualPower = Math.min(spiritualPower + amount, maxSpiritualPower);
    }

    public void consumeSpiritualPower(int amount) {
        this.spiritualPower = Math.max(spiritualPower - amount, 0);
    }

    public float getSpiritualPowerRatio() {
        return maxSpiritualPower > 0 ? (float) spiritualPower / maxSpiritualPower : 0;
    }

    public void addExp(int amount) {
        if (!hasStartedCultivation) return;
        
        double multiplier = spiritualRoot.getExpMultiplier();
        int actualExp = (int) (amount * multiplier);
        this.currentExp += actualExp;
        
        checkLevelUp();
        
        updateMaxSpiritualPower();
    }

    private void updateMaxSpiritualPower() {
        this.maxSpiritualPower = 100 + (realm.getLevel() * 50);
    }

    public boolean checkLevelUp() {
        if (realm.isMaxRealm()) return false;
        
        CultivationRealm nextRealm = realm.getNextRealm();
        if (currentExp >= nextRealm.getRequiredExp()) {
            currentExp -= nextRealm.getRequiredExp();
            realm = nextRealm;
            return true;
        }
        return false;
    }

    public class_2487 toNBT() {
        class_2487 tag = new class_2487();
        tag.method_10569("realmLevel", realm.getLevel());
        tag.method_10569("currentExp", currentExp);
        tag.method_10569("spiritualRoot", spiritualRoot.ordinal());
        tag.method_10556("hasStartedCultivation", hasStartedCultivation);
        tag.method_10569("spiritualPower", spiritualPower);
        tag.method_10569("maxSpiritualPower", maxSpiritualPower);
        tag.method_10569("technique", technique.ordinal());
        
        class_2499 skillsList = new class_2499();
        for (String skill : learnedSkills) {
            skillsList.add(class_2519.method_23256(skill));
        }
        tag.method_10566("learnedSkills", skillsList);
        
        return tag;
    }

    public void fromNBT(class_2487 tag) {
        this.realm = CultivationRealm.fromLevel(tag.method_10550("realmLevel"));
        this.currentExp = tag.method_10550("currentExp");
        this.spiritualRoot = SpiritualRoot.values()[tag.method_10550("spiritualRoot")];
        this.hasStartedCultivation = tag.method_10577("hasStartedCultivation");
        this.spiritualPower = tag.method_10550("spiritualPower");
        this.maxSpiritualPower = tag.method_10550("maxSpiritualPower");
        int techniqueIndex = tag.method_10550("technique");
        this.technique = techniqueIndex < CultivationTechnique.values().length ? 
            CultivationTechnique.values()[techniqueIndex] : CultivationTechnique.NONE;
        
        this.learnedSkills.clear();
        if (tag.method_10545("learnedSkills")) {
            class_2499 skillsList = tag.method_10554("learnedSkills", 8);
            for (int i = 0; i < skillsList.size(); i++) {
                learnedSkills.add(skillsList.method_10608(i));
            }
        }
    }

    public float getExpProgress() {
        if (realm.isMaxRealm()) return 1.0f;
        CultivationRealm nextRealm = realm.getNextRealm();
        return (float) currentExp / nextRealm.getRequiredExp();
    }

    public CultivationTechnique getTechnique() {
        return technique;
    }

    public void setTechnique(CultivationTechnique technique) {
        this.technique = technique;
    }

    public boolean canLearnTechnique(CultivationTechnique newTechnique) {
        if (newTechnique == CultivationTechnique.NONE) return true;
        return realm.getLevel() >= newTechnique.getLevel() - 1;
    }
    
    public boolean hasLearnedSkill(CultivationTechnique skill) {
        return learnedSkills.contains(skill.name());
    }
    
    public void learnSkill(CultivationTechnique skill) {
        if (skill.isActiveSkill()) {
            learnedSkills.add(skill.name());
        }
    }
    
    public Set<String> getLearnedSkills() {
        return learnedSkills;
    }
}
