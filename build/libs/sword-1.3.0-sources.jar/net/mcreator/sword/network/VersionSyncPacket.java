package net.mcreator.sword.network;

import net.mcreator.sword.SwordMod;
import net.mcreator.sword.version.VersionDetector;
import net.minecraft.class_2540;
import net.minecraft.class_2960;

public class VersionSyncPacket implements CultivationPacket {
    private final String version;
    private final boolean isLatest;
    
    public VersionSyncPacket() {
        this.version = VersionDetector.getCurrentVersion();
        this.isLatest = VersionDetector.isLatestVersion();
    }
    
    public VersionSyncPacket(class_2540 buffer) {
        this.version = buffer.method_19772();
        this.isLatest = buffer.readBoolean();
    }
    
    @Override
    public void encode(class_2540 buffer) {
        buffer.method_10814(version);
        buffer.writeBoolean(isLatest);
    }
    
    @Override
    public void handle(Context context) {
        System.out.println("[Sword Mod] 收到版本同步包: " + version + " (最新: " + isLatest + ")");
    }
    
    @Override
    public class_2960 getId() {
        return new class_2960(SwordMod.MODID, "version_sync");
    }
    
    public String getVersion() {
        return version;
    }
    
    public boolean isLatest() {
        return isLatest;
    }
}