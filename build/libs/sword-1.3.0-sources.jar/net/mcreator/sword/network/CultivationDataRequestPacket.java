package net.mcreator.sword.network;

import net.mcreator.sword.SwordMod;
import net.mcreator.sword.cultivation.CultivationManager;
import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;

public class CultivationDataRequestPacket implements CultivationPacket {
    public CultivationDataRequestPacket() {
    }
    
    public CultivationDataRequestPacket(class_2540 buffer) {
    }
    
    @Override
    public void encode(class_2540 buffer) {
    }
    
    @Override
    public void handle(Context context) {
        if (context.getPlayer() instanceof class_3222 serverPlayer) {
            CultivationDataSyncPacket syncPacket = new CultivationDataSyncPacket(
                CultivationManager.getCultivationData(serverPlayer)
            );
            class_2540 buffer = PacketByteBufs.create();
            syncPacket.encode(buffer);
            ServerPlayNetworking.send(serverPlayer, syncPacket.getId(), buffer);
        }
    }
    
    @Override
    public class_2960 getId() {
        return new class_2960(SwordMod.MODID, "cultivation_data_request");
    }
}