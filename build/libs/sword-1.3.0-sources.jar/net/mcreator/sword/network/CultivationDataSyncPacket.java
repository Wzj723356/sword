package net.mcreator.sword.network;

import net.mcreator.sword.SwordMod;
import net.mcreator.sword.cultivation.CultivationData;
import net.mcreator.sword.cultivation.CultivationRealm;
import net.mcreator.sword.cultivation.SpiritualRoot;
import net.minecraft.class_2540;
import net.minecraft.class_2960;

public class CultivationDataSyncPacket implements CultivationPacket {
    private final String realmName;
    private final int currentExp;
    private final String rootName;
    private final boolean hasStartedCultivation;
    private final int spiritualPower;
    private final int maxSpiritualPower;
    
    public CultivationDataSyncPacket(CultivationData data) {
        this.realmName = data.getRealm().name();
        this.currentExp = data.getCurrentExp();
        this.rootName = data.getSpiritualRoot().name();
        this.hasStartedCultivation = data.hasStartedCultivation();
        this.spiritualPower = data.getSpiritualPower();
        this.maxSpiritualPower = data.getMaxSpiritualPower();
    }
    
    public CultivationDataSyncPacket(class_2540 buffer) {
        this.realmName = buffer.method_19772();
        this.currentExp = buffer.readInt();
        this.rootName = buffer.method_19772();
        this.hasStartedCultivation = buffer.readBoolean();
        this.spiritualPower = buffer.readInt();
        this.maxSpiritualPower = buffer.readInt();
    }
    
    @Override
    public void encode(class_2540 buffer) {
        buffer.method_10814(realmName);
        buffer.writeInt(currentExp);
        buffer.method_10814(rootName);
        buffer.writeBoolean(hasStartedCultivation);
        buffer.writeInt(spiritualPower);
        buffer.writeInt(maxSpiritualPower);
    }
    
    @Override
    public void handle(Context context) {
        CultivationData data = new CultivationData();
        data.setRealm(CultivationRealm.valueOf(realmName));
        data.setCurrentExp(currentExp);
        data.setSpiritualRoot(SpiritualRoot.valueOf(rootName));
        data.setHasStartedCultivation(hasStartedCultivation);
        data.setMaxSpiritualPower(maxSpiritualPower);
        data.setSpiritualPower(spiritualPower);
        
        CultivationDataCache.setCachedData(data);
    }
    
    @Override
    public class_2960 getId() {
        return new class_2960(SwordMod.MODID, "cultivation_data_sync");
    }
    
    public CultivationData getData() {
        CultivationData data = new CultivationData();
        data.setRealm(CultivationRealm.valueOf(realmName));
        data.setCurrentExp(currentExp);
        data.setSpiritualRoot(SpiritualRoot.valueOf(rootName));
        data.setHasStartedCultivation(hasStartedCultivation);
        data.setMaxSpiritualPower(maxSpiritualPower);
        data.setSpiritualPower(spiritualPower);
        return data;
    }
}