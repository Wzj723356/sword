package net.mcreator.sword.network;

import net.mcreator.sword.SwordMod;
import net.minecraft.class_2540;
import net.minecraft.class_2960;

public interface CultivationPacket {
    void encode(class_2540 buffer);
    void handle(CultivationPacket.Context context);
    
    class_2960 getId();
    
    class Context {
        private final net.minecraft.class_1937 level;
        private final net.minecraft.class_1657 player;
        
        public Context(net.minecraft.class_1937 level, net.minecraft.class_1657 player) {
            this.level = level;
            this.player = player;
        }
        
        public net.minecraft.class_1937 getLevel() {
            return level;
        }
        
        public net.minecraft.class_1657 getPlayer() {
            return player;
        }
    }
}