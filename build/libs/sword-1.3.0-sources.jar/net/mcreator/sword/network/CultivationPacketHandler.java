package net.mcreator.sword.network;

import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.mcreator.sword.SwordMod;
import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_3222;

public class CultivationPacketHandler {
    public static void register() {
        ServerPlayNetworking.registerGlobalReceiver(
            new class_2960(SwordMod.MODID, "cultivation_data_request"),
            (server, player, handler, buffer, responseSender) -> {
                CultivationDataRequestPacket packet = new CultivationDataRequestPacket(buffer);
                packet.handle(new CultivationPacket.Context(player.method_37908(), player));
            }
        );
        
        ServerPlayConnectionEvents.JOIN.register((handler, sender, server) -> {
            class_3222 player = handler.method_32311();
            sendCultivationDataToClient(player);
            sendVersionToClient(player);
        });
    }
    
    public static void sendVersionToClient(class_3222 player) {
        VersionSyncPacket packet = new VersionSyncPacket();
        class_2540 buffer = PacketByteBufs.create();
        packet.encode(buffer);
        ServerPlayNetworking.send(player, packet.getId(), buffer);
    }
    
    public static void sendCultivationDataToClient(class_3222 player) {
        CultivationDataSyncPacket packet = new CultivationDataSyncPacket(
            net.mcreator.sword.cultivation.CultivationManager.getCultivationData(player)
        );
        class_2540 buffer = PacketByteBufs.create();
        packet.encode(buffer);
        ServerPlayNetworking.send(player, packet.getId(), buffer);
    }
}