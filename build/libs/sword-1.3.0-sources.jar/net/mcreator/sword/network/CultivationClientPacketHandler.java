package net.mcreator.sword.network;

import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.mcreator.sword.SwordMod;
import net.mcreator.sword.client.CultivationUI;
import net.minecraft.class_2540;
import net.minecraft.class_2960;

public class CultivationClientPacketHandler {
    public static void register() {
        ClientPlayNetworking.registerGlobalReceiver(
            new class_2960(SwordMod.MODID, "cultivation_data_sync"),
            (client, handler, buffer, responseSender) -> {
                CultivationDataSyncPacket packet = new CultivationDataSyncPacket(buffer);
                client.execute(() -> {
                    packet.handle(new CultivationPacket.Context(client.field_1687, client.field_1724));
                    CultivationUI.onCultivationDataReceived();
                });
            }
        );
        
        ClientPlayNetworking.registerGlobalReceiver(
            new class_2960(SwordMod.MODID, "version_sync"),
            (client, handler, buffer, responseSender) -> {
                VersionSyncPacket packet = new VersionSyncPacket(buffer);
                client.execute(() -> {
                    packet.handle(new CultivationPacket.Context(client.field_1687, client.field_1724));
                });
            }
        );
    }
    
    public static void requestCultivationData() {
        CultivationDataRequestPacket packet = new CultivationDataRequestPacket();
        class_2540 buffer = PacketByteBufs.create();
        packet.encode(buffer);
        ClientPlayNetworking.send(packet.getId(), buffer);
    }
}