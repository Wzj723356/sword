package net.mcreator.sword.items;

import net.mcreator.sword.cultivation.CultivationManager;
import net.mcreator.sword.cultivation.CultivationData;
import net.mcreator.sword.cultivation.SkillManager;
import net.minecraft.class_1268;
import net.minecraft.class_1271;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2561;
import net.mcreator.sword.cultivation.CultivationTechnique;

public class SkillBook extends class_1792 {
    private final CultivationTechnique technique;

    public SkillBook(CultivationTechnique technique) {
        super(new class_1792.class_1793().method_7889(1));
        this.technique = technique;
    }

    @Override
    public class_1271<class_1799> method_7836(class_1937 level, class_1657 player, class_1268 hand) {
        class_1799 stack = player.method_5998(hand);
        
        if (!level.field_9236) {
            CultivationData data = CultivationManager.getCultivationData(player);
            
            if (!data.hasStartedCultivation()) {
                player.method_7353(class_2561.method_43470("尚未开始修仙，无法学习"), true);
                return class_1271.method_22431(stack);
            }
            
            if (!data.canLearnTechnique(technique)) {
                player.method_7353(class_2561.method_43470("境界不足，无法学习 " + technique.getDisplayName()), true);
                return class_1271.method_22431(stack);
            }
            
            // 被动功法
            if (technique.isPassiveSkill()) {
                if (data.getTechnique() == technique) {
                    player.method_7353(class_2561.method_43470("已经学会了 " + technique.getDisplayName()), true);
                    return class_1271.method_22431(stack);
                }
                data.setTechnique(technique);
                player.method_7353(class_2561.method_43470("学会了功法 " + technique.getDisplayName() + "！"), true);
            }
            // 主动技能
            else if (technique.isActiveSkill()) {
                if (data.hasLearnedSkill(technique)) {
                    player.method_7353(class_2561.method_43470("已经学会了技能 " + technique.getDisplayName()), true);
                    return class_1271.method_22431(stack);
                }
                data.learnSkill(technique);
                player.method_7353(class_2561.method_43470("学会了技能 " + technique.getDisplayName() + "！"), true);
            }
            
            player.method_7353(class_2561.method_43470(technique.getDescription()), false);
            CultivationManager.saveCultivationData(player, data);
            
            if (player instanceof net.minecraft.class_3222 serverPlayer) {
                CultivationManager.syncToClient(serverPlayer);
            }
            
            stack.method_7934(1);
        }
        
        return class_1271.method_22427(stack);
    }

    @Override
    public class_2561 method_7864(class_1799 stack) {
        String type = technique.isActiveSkill() ? "技能书" : "功法书";
        return class_2561.method_43470(technique.getDisplayName() + " " + type);
    }

    public CultivationTechnique getTechnique() {
        return technique;
    }
}