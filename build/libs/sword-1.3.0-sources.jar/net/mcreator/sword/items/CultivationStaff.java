package net.mcreator.sword.items;

import net.mcreator.sword.cultivation.CultivationManager;
import net.minecraft.class_1268;
import net.minecraft.class_1271;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1814;
import net.minecraft.class_1836;
import net.minecraft.class_1937;
import net.minecraft.class_2561;
import java.util.List;

public class CultivationStaff extends class_1792 {
    public CultivationStaff() {
        super(new class_1792.class_1793().method_7889(1).method_7894(class_1814.field_8904));
    }

    @Override
    public class_1271<class_1799> method_7836(class_1937 level, class_1657 player, class_1268 hand) {
        class_1799 stack = player.method_5998(hand);
        
        if (!level.field_9236) {
            CultivationManager.addExperience(player, 10);
            
            if (CultivationManager.checkLevelUp(player)) {
                player.method_7353(class_2561.method_43470("境界提升！当前境界：" + CultivationManager.getCultivationData(player).getRealm().getDisplayName()), true);
            } else {
                player.method_7353(class_2561.method_43470("修炼成功！获得10点修仙经验"), true);
            }
            
            if (player instanceof net.minecraft.class_3222 serverPlayer) {
                CultivationManager.syncToClient(serverPlayer);
            }
        }
        
        return class_1271.method_22427(stack);
    }

    @Override
    public void method_7851(class_1799 stack, class_1937 level, List<class_2561> tooltip, class_1836 context) {
        tooltip.add(class_2561.method_43470("修仙法杖"));
        tooltip.add(class_2561.method_43470("右键使用可修炼，获得修仙经验"));
        tooltip.add(class_2561.method_43470("根据灵根不同，经验获取速度不同"));
    }
}
