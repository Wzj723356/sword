package net.mcreator.sword.items;

import java.util.List;
import net.mcreator.sword.entity.ArrayEntity;
import net.minecraft.class_1268;
import net.minecraft.class_1271;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_239;
import net.minecraft.class_2398;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_3218;

public class MagicWandItem extends class_1792 {
    private final String magicType;

    public MagicWandItem(String magicType, class_1792.class_1793 properties) {
        super(properties);
        this.magicType = magicType;
    }

    @Override
    public class_1271<class_1799> method_7836(class_1937 level, class_1657 player, class_1268 hand) {
        class_1799 stack = player.method_5998(hand);
        
        if (level.field_9236) {
            return class_1271.method_22430(stack);
        }

        class_239 hit = player.method_5745(20.0, 0.0f, false);
        class_243 target = hit.method_17784();
        
        switch (magicType) {
            case "break":
                performBreakMagic(level, player, target);
                break;
            case "detect":
                performDetectMagic(level, player);
                break;
            case "seal":
                performSealMagic(level, player, target);
                break;
        }
        
        return class_1271.method_22427(stack);
    }

    private void performBreakMagic(class_1937 level, class_1657 player, class_243 target) {
        class_2338 targetPos = new class_2338((int)target.field_1352, (int)target.field_1351, (int)target.field_1350);
        class_238 searchBox = new class_238(targetPos).method_1014(15.0);
        var arrays = level.method_18467(ArrayEntity.class, searchBox);
        
        int breakCount = 0;
        for (ArrayEntity array : arrays) {
            array.method_31472();
            breakCount++;
            
            if (level instanceof class_3218 serverLevel) {
                for (int i = 0; i < 80; i++) {
                    serverLevel.method_14199(class_2398.field_11216,
                        array.method_23317() + (level.field_9229.method_43058() - 0.5) * 4.0,
                        array.method_23318() + 0.5 + level.field_9229.method_43058() * 2.0,
                        array.method_23321() + (level.field_9229.method_43058() - 0.5) * 4.0,
                        1, 0, 0.1, 0, 0);
                }
                
                for (int i = 0; i < 50; i++) {
                    serverLevel.method_14199(class_2398.field_38908,
                        array.method_23317() + (level.field_9229.method_43058() - 0.5) * 3.0,
                        array.method_23318() + 0.5 + level.field_9229.method_43058() * 1.5,
                        array.method_23321() + (level.field_9229.method_43058() - 0.5) * 3.0,
                        1, 0, 0.05, 0, 0);
                }
            }
        }
        
        player.method_7353(class_2561.method_43470("超位魔法·破阵！破除了" + breakCount + "个法阵！"), true);
        
        if (level instanceof class_3218 serverLevel) {
            for (int i = 0; i < 100; i++) {
                double angle = i * Math.PI * 2 / 100;
                double radius = 5.0;
                double x = target.field_1352 + Math.cos(angle) * radius;
                double z = target.field_1350 + Math.sin(angle) * radius;
                
                serverLevel.method_14199(class_2398.field_11216, x, target.field_1351, z, 1, 0, 0.1, 0, 0.02);
            }
            
            for (int i = 0; i < 60; i++) {
                serverLevel.method_14199(class_2398.field_38908,
                    target.field_1352 + (level.field_9229.method_43058() - 0.5) * 6.0,
                    target.field_1351 + level.field_9229.method_43058() * 3.0,
                    target.field_1350 + (level.field_9229.method_43058() - 0.5) * 6.0,
                    1, 0, 0.1, 0, 0);
            }
        }
    }

    private void performDetectMagic(class_1937 level, class_1657 player) {
        class_238 searchBox = new class_238(player.method_24515()).method_1014(50.0);
        var arrays = level.method_18467(ArrayEntity.class, searchBox);
        
        if (arrays.isEmpty()) {
            player.method_7353(class_2561.method_43470("超位魔法·探查：附近没有发现法阵"), true);
        } else {
            player.method_7353(class_2561.method_43470("超位魔法·探查：发现" + arrays.size() + "个法阵"), true);
            
            if (level instanceof class_3218 serverLevel) {
                for (ArrayEntity array : arrays) {
                    for (int i = 0; i < 30; i++) {
                        serverLevel.method_14199(class_2398.field_11215,
                            array.method_23317() + (level.field_9229.method_43058() - 0.5) * 2.0,
                            array.method_23318() + 0.5 + level.field_9229.method_43058() * 1.0,
                            array.method_23321() + (level.field_9229.method_43058() - 0.5) * 2.0,
                            1, 0, 0.05, 0, 0);
                    }
                    
                    serverLevel.method_14199(class_2398.field_11207,
                        array.method_23317(), array.method_23318() + 0.5, array.method_23321(),
                        1, 0, 0.1, 0, 0);
                }
            }
        }
    }

    private void performSealMagic(class_1937 level, class_1657 player, class_243 target) {
        class_2338 targetPos = new class_2338((int)target.field_1352, (int)target.field_1351, (int)target.field_1350);
        class_238 searchBox = new class_238(targetPos).method_1014(10.0);
        var arrays = level.method_18467(ArrayEntity.class, searchBox);
        
        int sealCount = 0;
        for (ArrayEntity array : arrays) {
            array.setSealed(true);
            sealCount++;
            
            if (level instanceof class_3218 serverLevel) {
                for (int i = 0; i < 60; i++) {
                    double angle = i * Math.PI * 2 / 60;
                    double radius = 3.0;
                    double x = array.method_23317() + Math.cos(angle) * radius;
                    double z = array.method_23321() + Math.sin(angle) * radius;
                    
                    serverLevel.method_14199(class_2398.field_11220, x, array.method_23318() + 0.5, z, 1, 0, 0.05, 0, 0.02);
                }
                
                for (int i = 0; i < 40; i++) {
                    serverLevel.method_14199(class_2398.field_11215,
                        array.method_23317() + (level.field_9229.method_43058() - 0.5) * 3.0,
                        array.method_23318() + 0.5 + level.field_9229.method_43058() * 1.5,
                        array.method_23321() + (level.field_9229.method_43058() - 0.5) * 3.0,
                        1, 0, 0.05, 0, 0);
                }
            }
        }
        
        player.method_7353(class_2561.method_43470("超位魔法·封印！封印了" + sealCount + "个法阵！"), true);
        
        if (level instanceof class_3218 serverLevel) {
            for (int i = 0; i < 80; i++) {
                double angle = i * Math.PI * 2 / 80;
                double radius = 4.0;
                double x = target.field_1352 + Math.cos(angle) * radius;
                double z = target.field_1350 + Math.sin(angle) * radius;
                
                serverLevel.method_14199(class_2398.field_11220, x, target.field_1351, z, 1, 0, 0.05, 0, 0.02);
            }
            
            for (int i = 0; i < 50; i++) {
                serverLevel.method_14199(class_2398.field_11215,
                    target.field_1352 + (level.field_9229.method_43058() - 0.5) * 5.0,
                    target.field_1351 + level.field_9229.method_43058() * 2.0,
                    target.field_1350 + (level.field_9229.method_43058() - 0.5) * 5.0,
                    1, 0, 0.05, 0, 0);
            }
        }
    }

    @Override
    public boolean method_7886(class_1799 stack) {
        return true;
    }

    public String getMagicType() {
        return magicType;
    }
}