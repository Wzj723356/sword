package net.mcreator.sword.items;

import net.mcreator.sword.entity.CloudBoatEntity;
import net.minecraft.class_1268;
import net.minecraft.class_1271;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1814;
import net.minecraft.class_1937;

public class CloudBoatItem extends class_1792 {
    public CloudBoatItem() {
        super(new class_1792.class_1793().method_7889(1).method_7894(class_1814.field_8904));
    }

    @Override
    public class_1271<class_1799> method_7836(class_1937 level, class_1657 player, class_1268 hand) {
        class_1799 stack = player.method_5998(hand);
        
        if (!level.field_9236) {
            CloudBoatEntity cloudBoat = new CloudBoatEntity(level, player.method_23317(), player.method_23318(), player.method_23321());
            level.method_8649(cloudBoat);
            player.method_5804(cloudBoat);
            
            if (!player.method_31549().field_7477) {
                stack.method_7934(1);
            }
        }
        
        return class_1271.method_22427(stack);
    }
}