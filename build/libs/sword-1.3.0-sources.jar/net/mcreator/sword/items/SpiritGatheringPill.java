package net.mcreator.sword.items;

import net.mcreator.sword.cultivation.CultivationManager;
import net.minecraft.class_1268;
import net.minecraft.class_1271;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2561;
import net.mcreator.sword.cultivation.CultivationData;

public class SpiritGatheringPill extends class_1792 {
    public SpiritGatheringPill() {
        super(new class_1792.class_1793().method_7889(64));
    }

    @Override
    public class_1271<class_1799> method_7836(class_1937 level, class_1657 player, class_1268 hand) {
        class_1799 stack = player.method_5998(hand);
        
        if (!level.field_9236) {
            CultivationData cultivationData = CultivationManager.getCultivationData(player);
            
            if (cultivationData.hasStartedCultivation()) {
                // 检查灵力是否回满
                if (cultivationData.getSpiritualPower() >= cultivationData.getMaxSpiritualPower()) {
                    // 灵力回满，开始修炼
                    CultivationManager.addExperience(player, 100);
                    player.method_7353(class_2561.method_43470("服用聚灵丹，灵力回满开始修炼，获得100点修仙经验"), true);
                    stack.method_7934(1);
                    
                    if (player instanceof net.minecraft.class_3222 serverPlayer) {
                        CultivationManager.syncToClient(serverPlayer);
                    }
                } else {
                    // 灵力未回满
                    player.method_7353(class_2561.method_43470("灵力未回满，无法开始修炼"), true);
                }
            } else {
                player.method_7353(class_2561.method_43470("尚未开始修仙，无法服用聚灵丹"), true);
            }
        }
        
        return class_1271.method_22427(stack);
    }
}
