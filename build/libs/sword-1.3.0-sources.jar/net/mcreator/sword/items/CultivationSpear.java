package net.mcreator.sword.items;

import net.mcreator.sword.cultivation.CultivationManager;
import net.mcreator.sword.cultivation.CultivationData;
import net.mcreator.sword.cultivation.SkillManager;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1829;
import net.minecraft.class_1834;
import net.mcreator.sword.cultivation.CultivationTechnique;

public class CultivationSpear extends class_1829 {
    public CultivationSpear() {
        super(class_1834.field_22033, 4, -2.6F, new class_1792.class_1793());
    }

    @Override
    public boolean method_7873(class_1799 stack, class_1309 target, class_1309 attacker) {
        if (attacker instanceof class_1657 player) {
            CultivationData data = CultivationManager.getCultivationData(player);
            if (data.hasStartedCultivation()) {
                CultivationTechnique technique = data.getTechnique();
                
                // 应用功法伤害加成
                if (technique.isPassiveSkill() && (technique.name().startsWith("SPEAR_"))) {
                    float damageMultiplier = (float) technique.getDamageMultiplier();
                    target.method_5643(player.method_37908().method_48963().method_48802(player), 4.0F * (damageMultiplier - 1.0F));
                }
                
                // 应用技能伤害加成
                float skillMultiplier = SkillManager.getDamageMultiplier(player);
                if (skillMultiplier > 1.0F) {
                    target.method_5643(player.method_37908().method_48963().method_48802(player), 4.0F * (skillMultiplier - 1.0F));
                }
                
                // 消耗少量灵力
                if (data.getSpiritualPower() >= 2) {
                    data.consumeSpiritualPower(2);
                    CultivationManager.saveCultivationData(player, data);
                }
            }
        }
        return super.method_7873(stack, target, attacker);
    }
}
