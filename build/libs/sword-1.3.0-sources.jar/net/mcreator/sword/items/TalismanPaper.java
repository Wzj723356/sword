package net.mcreator.sword.items;

import net.minecraft.class_1268;
import net.minecraft.class_1271;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1814;
import net.minecraft.class_1937;
import net.minecraft.class_243;
import net.minecraft.class_2561;

public class TalismanPaper extends class_1792 {
    private final TalismanType type;

    public TalismanPaper(TalismanType type) {
        super(new class_1792.class_1793().method_7889(64).method_7894(type.getRarity()));
        this.type = type;
    }

    @Override
    public class_1271<class_1799> method_7836(class_1937 level, class_1657 player, class_1268 hand) {
        class_1799 stack = player.method_5998(hand);
        
        if (!level.field_9236) {
            switch (type) {
                case ATTACK:
                    performAttack(level, player);
                    break;
                case DEFENSE:
                    performDefense(player);
                    break;
                case HEALING:
                    performHealing(player);
                    break;
                case LIGHTNING:
                    performLightning(level, player);
                    break;
                case FIRE:
                    performFire(level, player);
                    break;
                case ICE:
                    performIce(level, player);
                    break;
                case WIND:
                    performWind(level, player);
                    break;
                case TELEPORT:
                    performTeleport(level, player);
                    break;
            }
            
            if (!player.method_31549().field_7477) {
                stack.method_7934(1);
            }
        }
        
        return class_1271.method_22427(stack);
    }

    private void performAttack(class_1937 level, class_1657 player) {
        class_243 look = player.method_5720();
        class_243 start = player.method_33571();
        class_243 end = start.method_1019(look.method_1021(5.0));
        
        for (class_1297 entity : level.method_18467(class_1309.class, player.method_5829().method_1014(5.0))) {
            if (entity != player && entity.method_5739(player) <= 5.0) {
                entity.method_5643(level.method_48963().method_48802(player), 10.0F);
            }
        }
        
        player.method_7353(class_2561.method_43470("攻击符纸发动！"), true);
    }

    private void performDefense(class_1657 player) {
        player.method_6092(new class_1293(class_1294.field_5907, 600, 2, false, false));
        player.method_6092(new class_1293(class_1294.field_5898, 600, 2, false, false));
        player.method_7353(class_2561.method_43470("防御符纸发动！"), true);
    }

    private void performHealing(class_1657 player) {
        player.method_6025(15.0F);
        player.method_6092(new class_1293(class_1294.field_5924, 200, 1, false, false));
        player.method_7353(class_2561.method_43470("治疗符纸发动！"), true);
    }

    private void performLightning(class_1937 level, class_1657 player) {
        class_243 look = player.method_5720();
        class_243 target = player.method_33571().method_1019(look.method_1021(10.0));
        
        for (class_1297 entity : level.method_18467(class_1309.class, player.method_5829().method_1014(10.0))) {
            if (entity != player && entity.method_5739(player) <= 10.0) {
                entity.method_5643(level.method_48963().method_48831(), 15.0F);
                entity.method_5639(3);
            }
        }
        
        player.method_7353(class_2561.method_43470("雷符发动！"), true);
    }

    private void performFire(class_1937 level, class_1657 player) {
        class_243 look = player.method_5720();
        class_243 target = player.method_33571().method_1019(look.method_1021(8.0));
        
        for (class_1297 entity : level.method_18467(class_1309.class, player.method_5829().method_1014(8.0))) {
            if (entity != player && entity.method_5739(player) <= 8.0) {
                entity.method_5639(10);
                entity.method_5643(level.method_48963().method_48813(), 8.0F);
            }
        }
        
        player.method_7353(class_2561.method_43470("火符发动！"), true);
    }

    private void performIce(class_1937 level, class_1657 player) {
        class_243 look = player.method_5720();
        
        for (class_1297 entity : level.method_18467(class_1309.class, player.method_5829().method_1014(6.0))) {
            if (entity != player && entity.method_5739(player) <= 6.0) {
                entity.method_32317(200);
                entity.method_5643(level.method_48963().method_48831(), 5.0F);
            }
        }
        
        player.method_7353(class_2561.method_43470("冰符发动！"), true);
    }

    private void performWind(class_1937 level, class_1657 player) {
        class_243 look = player.method_5720();
        class_243 velocity = look.method_1021(2.0);
        
        for (class_1297 entity : level.method_18467(class_1309.class, player.method_5829().method_1014(4.0))) {
            if (entity != player && entity.method_5739(player) <= 4.0) {
                entity.method_18799(velocity);
                entity.method_5643(level.method_48963().method_48802(player), 6.0F);
            }
        }
        
        player.method_7353(class_2561.method_43470("风符发动！"), true);
    }

    private void performTeleport(class_1937 level, class_1657 player) {
        class_243 look = player.method_5720();
        class_243 target = player.method_33571().method_1019(look.method_1021(15.0));
        
        player.method_5859(target.field_1352, target.field_1351, target.field_1350);
        player.method_7353(class_2561.method_43470("传送符纸发动！"), true);
    }

    public TalismanType getType() {
        return type;
    }

    public enum TalismanType {
        ATTACK("攻击符纸", class_1814.field_8906),
        DEFENSE("防御符纸", class_1814.field_8907),
        HEALING("治疗符纸", class_1814.field_8907),
        LIGHTNING("雷符", class_1814.field_8903),
        FIRE("火符", class_1814.field_8903),
        ICE("冰符", class_1814.field_8903),
        WIND("风符", class_1814.field_8903),
        TELEPORT("传送符纸", class_1814.field_8904);

        private final String displayName;
        private final class_1814 rarity;

        TalismanType(String displayName, class_1814 rarity) {
            this.displayName = displayName;
            this.rarity = rarity;
        }

        public String getDisplayName() {
            return displayName;
        }

        public class_1814 getRarity() {
            return rarity;
        }
    }
}