package net.mcreator.sword.items;

import net.mcreator.sword.cultivation.CultivationManager;
import net.mcreator.sword.cultivation.CultivationData;
import net.mcreator.sword.cultivation.SkillManager;
import net.minecraft.class_1268;
import net.minecraft.class_1271;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2561;
import net.mcreator.sword.cultivation.CultivationTechnique;

public class SkillCastItem extends class_1792 {
    private final CultivationTechnique technique;

    public SkillCastItem(CultivationTechnique technique) {
        super(new class_1792.class_1793().method_7889(1));
        this.technique = technique;
    }

    @Override
    public class_1271<class_1799> method_7836(class_1937 level, class_1657 player, class_1268 hand) {
        class_1799 stack = player.method_5998(hand);
        
        if (!level.field_9236) {
            CultivationData data = CultivationManager.getCultivationData(player);
            
            if (!data.hasStartedCultivation()) {
                player.method_7353(class_2561.method_43470("尚未开始修仙，无法使用技能"), true);
                return class_1271.method_22431(stack);
            }
            
            if (!data.canLearnTechnique(technique)) {
                player.method_7353(class_2561.method_43470("境界不足，无法使用 " + technique.getDisplayName()), true);
                return class_1271.method_22431(stack);
            }
            
            if (SkillManager.canUseSkill(player, technique)) {
                SkillManager.useSkill(player, technique);
                
                if (player instanceof net.minecraft.class_3222 serverPlayer) {
                    CultivationManager.syncToClient(serverPlayer);
                }
            }
        }
        
        return class_1271.method_22427(stack);
    }

    @Override
    public class_2561 method_7864(class_1799 stack) {
        return class_2561.method_43470(technique.getDisplayName());
    }

    public CultivationTechnique getTechnique() {
        return technique;
    }
}