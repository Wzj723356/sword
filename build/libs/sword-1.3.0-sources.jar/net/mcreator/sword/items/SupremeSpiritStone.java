package net.mcreator.sword.items;

import net.minecraft.class_1792;
import net.minecraft.class_1814;

public class SupremeSpiritStone extends class_1792 {
    public SupremeSpiritStone() {
        super(new class_1792.class_1793().method_7889(64).method_7894(class_1814.field_8904));
    }
}
