package net.mcreator.sword.items;

import net.mcreator.sword.cultivation.CultivationManager;
import net.minecraft.class_1268;
import net.minecraft.class_1271;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2561;
import net.mcreator.sword.cultivation.CultivationData;

public class HealingPill extends class_1792 {
    public HealingPill() {
        super(new class_1792.class_1793().method_7889(64));
    }

    @Override
    public class_1271<class_1799> method_7836(class_1937 level, class_1657 player, class_1268 hand) {
        class_1799 stack = player.method_5998(hand);
        
        if (!level.field_9236) {
            CultivationData cultivationData = CultivationManager.getCultivationData(player);
            
            if (cultivationData.hasStartedCultivation()) {
                player.method_6025(10.0F);
                cultivationData.addSpiritualPower(20);
                CultivationManager.saveCultivationData(player, cultivationData);
                player.method_7353(class_2561.method_43470("服用回血丹，恢复10点生命和20点灵力"), true);
                stack.method_7934(1);
                
                if (player instanceof net.minecraft.class_3222 serverPlayer) {
                    CultivationManager.syncToClient(serverPlayer);
                }
            } else {
                player.method_7353(class_2561.method_43470("尚未开始修仙，无法服用回血丹"), true);
            }
        }
        
        return class_1271.method_22427(stack);
    }
}
