package net.mcreator.sword.items;

import net.mcreator.sword.cultivation.CultivationManager;
import net.mcreator.sword.cultivation.SpiritualRoot;
import net.minecraft.class_1268;
import net.minecraft.class_1271;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1814;
import net.minecraft.class_1836;
import net.minecraft.class_1937;
import net.minecraft.class_2561;
import java.util.List;

public class SpiritualRootReforgingPill extends class_1792 {
    public SpiritualRootReforgingPill() {
        super(new class_1792.class_1793().method_7889(1).method_7894(class_1814.field_8904));
    }

    @Override
    public class_1271<class_1799> method_7836(class_1937 level, class_1657 player, class_1268 hand) {
        class_1799 stack = player.method_5998(hand);
        
        if (!level.field_9236) {
            net.mcreator.sword.cultivation.CultivationData data = CultivationManager.getCultivationData(player);
            SpiritualRoot oldRoot = data.getSpiritualRoot();
            SpiritualRoot newRoot = SpiritualRoot.randomRoot(player.method_6051());
            
            while (newRoot == oldRoot && newRoot != SpiritualRoot.NONE) {
                newRoot = SpiritualRoot.randomRoot(player.method_6051());
            }
            
            data.setSpiritualRoot(newRoot);
            CultivationManager.saveCultivationData(player, data);
            
            player.method_7353(class_2561.method_43470("灵根重铸成功！"), true);
            player.method_7353(class_2561.method_43470("原灵根：" + oldRoot.getDisplayName()), false);
            player.method_7353(class_2561.method_43470("新灵根：" + newRoot.getDisplayName()), false);
            
            stack.method_7934(1);
            
            if (player instanceof net.minecraft.class_3222 serverPlayer) {
                CultivationManager.syncToClient(serverPlayer);
            }
        }
        
        return class_1271.method_22427(stack);
    }

    @Override
    public void method_7851(class_1799 stack, class_1937 level, List<class_2561> tooltip, class_1836 context) {
        tooltip.add(class_2561.method_43470("灵根重铸丹"));
        tooltip.add(class_2561.method_43470("使用后重新随机灵根"));
        tooltip.add(class_2561.method_43470("极难获得，请谨慎使用"));
    }
}