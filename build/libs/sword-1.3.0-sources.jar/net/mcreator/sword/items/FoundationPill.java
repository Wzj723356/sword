package net.mcreator.sword.items;

import net.mcreator.sword.cultivation.CultivationManager;
import net.minecraft.class_1268;
import net.minecraft.class_1271;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2561;

public class FoundationPill extends class_1792 {
    public FoundationPill() {
        super(new class_1792.class_1793().method_7889(64));
    }

    @Override
    public class_1271<class_1799> method_7836(class_1937 level, class_1657 player, class_1268 hand) {
        class_1799 stack = player.method_5998(hand);
        
        if (!level.field_9236) {
            CultivationManager.addExperience(player, 500);
            player.method_7353(class_2561.method_43470("服用筑基丹，获得500点修仙经验"), true);
            stack.method_7934(1);
            
            if (player instanceof net.minecraft.class_3222 serverPlayer) {
                CultivationManager.syncToClient(serverPlayer);
            }
        }
        
        return class_1271.method_22427(stack);
    }
}
