package net.mcreator.sword.items;

import net.mcreator.sword.entity.ArrayEntity;
import net.mcreator.sword.init.SwordModEntities;
import net.minecraft.class_1268;
import net.minecraft.class_1271;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_239;
import net.minecraft.class_2561;
import net.minecraft.class_3965;
import net.minecraft.class_3966;

public class ArrayItem extends class_1792 {
    private final String arrayType;

    public ArrayItem(String arrayType, class_1792.class_1793 properties) {
        super(properties);
        this.arrayType = arrayType;
    }

    @Override
    public class_1271<class_1799> method_7836(class_1937 level, class_1657 player, class_1268 hand) {
        if (level.field_9236) {
            return class_1271.method_22430(player.method_5998(hand));
        }

        class_239 hit = player.method_5745(5.0, 0.0f, false);
        if (hit.method_17783() == class_239.class_240.field_1331) {
            class_3966 entityHit = (class_3966) hit;
            if (entityHit.method_17782() instanceof ArrayEntity array) {
                array.method_31472();
                player.method_7353(class_2561.method_43470("法阵已被破除！"), true);
                
                if (level instanceof net.minecraft.class_3218 serverLevel) {
                    for (int i = 0; i < 50; i++) {
                        serverLevel.method_14199(net.minecraft.class_2398.field_11251,
                            array.method_23317() + (level.field_9229.method_43058() - 0.5) * 3.0,
                            array.method_23318() + 0.5 + level.field_9229.method_43058() * 1.0,
                            array.method_23321() + (level.field_9229.method_43058() - 0.5) * 3.0,
                            1, 0, 0.05, 0, 0);
                    }
                }
                
                class_1799 stack = player.method_5998(hand);
                return class_1271.method_22427(stack);
            }
        }
        
        if (hit.method_17783() == class_239.class_240.field_1332) {
            class_3965 blockHit = (class_3965) hit;
            class_2338 pos = blockHit.method_17777();
            
            ArrayEntity array = new ArrayEntity(level, pos.method_10263() + 0.5, pos.method_10264() + 1.0, pos.method_10260() + 0.5, arrayType);
            level.method_8649(array);
            
            class_1799 stack = player.method_5998(hand);
            if (!player.method_31549().field_7477) {
                stack.method_7934(1);
            }
            
            return class_1271.method_22427(stack);
        }
        
        return class_1271.method_22430(player.method_5998(hand));
    }

    public String getArrayType() {
        return arrayType;
    }
}