package net.mcreator.sword;

import java.util.List;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1297;
import net.minecraft.class_1304;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1814;
import net.minecraft.class_1819;
import net.minecraft.class_1836;
import net.minecraft.class_1937;
import net.minecraft.class_2561;

public class DavoShield extends class_1819 {
    public DavoShield() {
        super(new class_1793().method_24359().method_7894(class_1814.field_8904).method_7895(Integer.MAX_VALUE));
    }

    @Override
    public void method_7843(class_1799 stack, class_1937 level, class_1657 player) {
        super.method_7843(stack, level, player);
        player.method_6092(new class_1293(class_1294.field_5924, Integer.MAX_VALUE, 255, false, false));
        player.method_6092(new class_1293(class_1294.field_5898, Integer.MAX_VALUE, 255, false, false));
        player.method_6092(new class_1293(class_1294.field_5922, Integer.MAX_VALUE, 255, false, false));
    }

    @Override
    public void method_7888(class_1799 stack, class_1937 level, class_1297 entity, int slot, boolean selected) {
        if (entity instanceof class_1657 player && player.method_6118(class_1304.field_6171).method_7909() == this) {
            player.method_6092(new class_1293(class_1294.field_5924, Integer.MAX_VALUE, 255, false, false));
            player.method_6092(new class_1293(class_1294.field_5898, Integer.MAX_VALUE, 255, false, false));
            player.method_6092(new class_1293(class_1294.field_5922, Integer.MAX_VALUE, 255, false, false));
        }
    }

    @Override
    public void method_7851(class_1799 itemstack, class_1937 world, List<class_2561> list, class_1836 flag) {
        super.method_7851(itemstack, world, list, flag);
        list.add(class_2561.method_43470("上古神器盾牌"));
        list.add(class_2561.method_43470("提供生命恢复、吸收和饱食效果"));
    }

    public class_1814 method_7862(class_1799 itemstack) {
        return class_1814.field_8904;
    }
}