package net.mcreator.sword.materials;

import net.minecraft.class_1738;
import net.minecraft.class_1741;
import net.minecraft.class_1802;
import net.minecraft.class_1856;
import net.minecraft.class_3414;
import net.minecraft.class_3417;

public class DavoArmorMaterial implements class_1741 {
    public static final DavoArmorMaterial INSTANCE = new DavoArmorMaterial();

    @Override
    public int method_48402(class_1738.class_8051 type) {
        return Integer.MAX_VALUE;
    }

    @Override
    public int method_48403(class_1738.class_8051 type) {
        return Integer.MAX_VALUE;
    }

    @Override
    public int method_7699() {
        return Integer.MAX_VALUE;
    }

    @Override
    public class_3414 method_7698() {
        return class_3417.field_21866;
    }

    @Override
    public class_1856 method_7695() {
        return class_1856.method_8091(class_1802.field_8600);
    }

    @Override
    public String method_7694() {
        return "davo";
    }

    @Override
    public float method_7700() {
        return 10.0F;
    }

    @Override
    public float method_24355() {
        return 1.0F;
    }
}