package net.mcreator.sword;

import java.util.List;
import net.minecraft.class_1268;
import net.minecraft.class_1271;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1814;
import net.minecraft.class_1829;
import net.minecraft.class_1832;
import net.minecraft.class_1836;
import net.minecraft.class_1856;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2398;
import net.minecraft.class_2561;
import net.minecraft.class_3417;
import net.minecraft.class_3419;

public class DavoItem extends class_1829 {
    public DavoItem() {
        super(new class_1832() {
            public int method_8025() {
                return Integer.MAX_VALUE;
            }

            public float method_8027() {
                return Float.MAX_VALUE;
            }

            public float method_8028() {
                return Float.MAX_VALUE;
            }

            public int method_8024() {
                return Integer.MAX_VALUE;
            }

            public int method_8026() {
                return Integer.MAX_VALUE;
            }

            public class_1856 method_8023() {
                return class_1856.method_8101(new class_1799(net.minecraft.class_1802.field_8477));
            }
        }, 3, -2.0F, new class_1792.class_1793()
                .method_24359()
                .method_7894(class_1814.field_8904));
    }

    @Override
    public void method_7843(class_1799 stack, class_1937 level, class_1657 player) {
        super.method_7843(stack, level, player);
        player.method_6092(new class_1293(class_1294.field_5917, Integer.MAX_VALUE, 255, false, false));
        player.method_6092(new class_1293(class_1294.field_5910, Integer.MAX_VALUE, 255, false, false));
        player.method_6092(new class_1293(class_1294.field_5907, Integer.MAX_VALUE, 255, false, false));
        player.method_6092(new class_1293(class_1294.field_5924, Integer.MAX_VALUE, 255, false, false));
        player.method_6092(new class_1293(class_1294.field_5898, Integer.MAX_VALUE, 255, false, false));
        player.method_6092(new class_1293(class_1294.field_5922, Integer.MAX_VALUE, 255, false, false));
    }

    @Override
    public void method_7888(class_1799 stack, class_1937 level, class_1297 entity, int slot, boolean selected) {
    }

    @Override
    public boolean method_7873(class_1799 stack, class_1309 target, class_1309 attacker) {
        boolean result = super.method_7873(stack, target, attacker);
        
        if (result && attacker instanceof class_1657 player) {
            class_1937 world = player.method_37908();
            class_2338 pos = target.method_24515();
            float radius = 5.0F;
            
            world.method_8396(null, pos, class_3417.field_14706, class_3419.field_15248, 1.5F, 0.8F);
            
            for (int i = 0; i < 20; i++) {
                double x = pos.method_10263() + 0.5 + (world.field_9229.method_43058() - 0.5) * radius * 2;
                double y = pos.method_10264() + 0.5 + (world.field_9229.method_43058() - 0.5) * radius * 2;
                double z = pos.method_10260() + 0.5 + (world.field_9229.method_43058() - 0.5) * radius * 2;
                world.method_8406(class_2398.field_11227, x, y, z, 0, 0, 0);
                world.method_8406(class_2398.field_11215, x, y, z, 0, 0, 0);
            }
            
            for (class_1309 entity : world.method_18467(class_1309.class, 
                    new net.minecraft.class_238(pos).method_1014(radius))) {
                if (entity != attacker && entity != target && !entity.method_5722(attacker)) {
                    entity.method_5643(world.method_48963().method_48802(player), 8.0F);
                }
            }
        }
        
        return result;
    }

    @Override
    public class_1271<class_1799> method_7836(class_1937 level, class_1657 player, class_1268 hand) {
        class_1799 stack = player.method_5998(hand);
        class_2338 playerPos = player.method_24515();
        float radius = 40.0F;
        
        level.method_8396(null, playerPos, class_3417.field_14934, class_3419.field_15248, 2.0F, 0.5F);
        
        for (int i = 0; i < 100; i++) {
            double x = playerPos.method_10263() + 0.5 + (level.field_9229.method_43058() - 0.5) * radius * 2;
            double y = playerPos.method_10264() + 0.5 + (level.field_9229.method_43058() - 0.5) * radius * 2;
            double z = playerPos.method_10260() + 0.5 + (level.field_9229.method_43058() - 0.5) * radius * 2;
            level.method_8406(class_2398.field_11236, x, y, z, 0, 0, 0);
            level.method_8406(class_2398.field_11216, x, y, z, 0, 0, 0);
        }
        
        for (class_1309 entity : level.method_18467(class_1309.class, 
                new net.minecraft.class_238(playerPos).method_1014(radius))) {
            if (entity != player && !entity.method_5722(player)) {
                entity.method_5643(level.method_48963().method_48802(player), Float.MAX_VALUE);
                entity.method_5639(10);
            }
        }
        
        return class_1271.method_22427(stack);
    }

    @Override
    public void method_7851(class_1799 itemstack, class_1937 world, List<class_2561> list, class_1836 flag) {
        super.method_7851(itemstack, world, list, flag);
        list.add(class_2561.method_43470("神之刃：Davo"));
        list.add(class_2561.method_43470("右键可范围攻击的神剑"));
        list.add(class_2561.method_43470("上古神器"));
    }

    public class_1814 method_7862(class_1799 itemstack) {
        return class_1814.field_8904;
    }
}