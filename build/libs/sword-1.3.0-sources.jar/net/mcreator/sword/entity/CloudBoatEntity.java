package net.mcreator.sword.entity;

import java.util.List;
import net.minecraft.class_1282;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1657;
import net.minecraft.class_1690;
import net.minecraft.class_1937;
import net.minecraft.class_243;
import net.minecraft.class_2487;
import net.minecraft.class_2940;
import net.minecraft.class_2943;
import net.minecraft.class_2945;

public class CloudBoatEntity extends class_1690 {
    private static final class_2940<Float> DATA_DAMAGE = class_2945.method_12791(CloudBoatEntity.class, class_2943.field_13320);
    private static final class_2940<Integer> DATA_TYPE = class_2945.method_12791(CloudBoatEntity.class, class_2943.field_13327);
    private static final class_2940<Boolean> DATA_PADDLE_LEFT = class_2945.method_12791(CloudBoatEntity.class, class_2943.field_13323);
    private static final class_2940<Boolean> DATA_PADDLE_RIGHT = class_2945.method_12791(CloudBoatEntity.class, class_2943.field_13323);
    private static final class_2940<Integer> DATA_BUBBLE_TIME = class_2945.method_12791(CloudBoatEntity.class, class_2943.field_13327);
    
    private float damage;
    private int lerpSteps;
    private double lerpX;
    private double lerpY;
    private double lerpZ;
    private double lerpYaw;
    private double lerpPitch;
    private boolean bubbleTime;
    private float bubbleAngle;
    private float bubbleAngleO;

    public CloudBoatEntity(class_1299<? extends class_1690> entityType, class_1937 level) {
        super(entityType, level);
        this.field_23807 = true;
    }

    public CloudBoatEntity(class_1937 level, double x, double y, double z) {
        this(net.mcreator.sword.init.SwordModEntities.CLOUD_BOAT, level);
        this.method_5814(x, y, z);
        this.field_6014 = x;
        this.field_6036 = y;
        this.field_5969 = z;
    }

    @Override
    protected void method_5693() {
        this.field_6011.method_12784(DATA_DAMAGE, 0.0F);
        this.field_6011.method_12784(DATA_TYPE, 0);
        this.field_6011.method_12784(DATA_PADDLE_LEFT, false);
        this.field_6011.method_12784(DATA_PADDLE_RIGHT, false);
        this.field_6011.method_12784(DATA_BUBBLE_TIME, 0);
    }

    @Override
    public void method_5773() {
        super.method_5773();
        
        if (!this.method_37908().field_9236) {
            this.method_5875(true);
            
            class_243 movement = class_243.field_1353;
            if (this.method_5642() instanceof class_1657 player) {
                float forward = player.field_6212 * 0.5F;
                float strafe = player.field_6250 * 0.5F;
                
                if (player.method_5715()) {
                    forward *= 2.0F;
                    strafe *= 2.0F;
                }
                
                movement = new class_243(strafe, 0, -forward);
            }
            
            this.method_18800(movement.field_1352, movement.field_1351, movement.field_1350);
            
            List<class_1297> passengers = this.method_5685();
            for (class_1297 passenger : passengers) {
                if (passenger instanceof class_1657 player) {
                    player.field_6017 = 0;
                    player.method_5875(true);
                }
            }
        }
    }

    @Override
    public void method_5650(class_5529 reason) {
        if (!this.method_37908().field_9236) {
            List<class_1297> passengers = this.method_5685();
            for (class_1297 passenger : passengers) {
                if (passenger instanceof class_1657 player) {
                    player.method_5875(false);
                }
            }
        }
        super.method_5650(reason);
    }

    public double getMaxSpeed() {
        return 1.5D;
    }

    @Override
    protected boolean method_5818(class_1297 passenger) {
        return this.method_5685().size() < 10;
    }

    @Override
    public boolean method_5643(class_1282 source, float amount) {
        if (this.method_5679(source)) {
            return false;
        } else {
            this.method_7542(this.method_7554() + amount * 10.0F);
            this.method_5785();
            boolean flag = this.method_5679(source);
            if (flag || this.method_7554() > 40.0F) {
                this.method_5650(class_5529.field_26998);
            }

            return !flag;
        }
    }

    public float method_7554() {
        return this.field_6011.method_12789(DATA_DAMAGE);
    }

    public void method_7542(float damage) {
        this.field_6011.method_12778(DATA_DAMAGE, damage);
    }

    @Override
    public void method_5652(class_2487 compound) {
        compound.method_10548("Damage", this.method_7554());
    }

    @Override
    public void method_5749(class_2487 compound) {
        if (compound.method_10573("Damage", 99)) {
            this.method_7542(compound.method_10583("Damage"));
        }
    }
}