/*
*	MCreator note:
*
*	If you lock base mod element files, you can edit this file and the proxy files
*	and they won't get overwritten. If you change your mod package or modid, you
*	need to apply these changes to this file MANUALLY.
*
*
*	If you do not lock base mod element files in Workspace settings, this file
*	will be REGENERATED on each build.
*
*/
package net.mcreator.sword;

import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;
import net.mcreator.sword.network.CultivationClientPacketHandler;
import net.minecraft.class_304;
import net.minecraft.class_3675;
import net.mcreator.sword.client.CultivationHUD;
import net.mcreator.sword.client.ArrayEntityRenderer;
import net.mcreator.sword.init.SwordModEntities;

import net.fabricmc.api.Environment;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.ClientModInitializer;
import org.lwjgl.glfw.GLFW;

@Environment(EnvType.CLIENT)
public class ClientInit implements ClientModInitializer {
	private static class_304 toggleHUDKey;

	@Override
	public void onInitializeClient() {
		CultivationClientPacketHandler.register();
		CultivationHUD.register();
		
		EntityRendererRegistry.register(SwordModEntities.ARRAY, ArrayEntityRenderer::new);
		
		toggleHUDKey = KeyBindingHelper.registerKeyBinding(new class_304(
			"key.sword.toggle_hud",
			class_3675.class_307.field_1668,
			GLFW.GLFW_KEY_K,
			"key.categories.sword"
		));

		ClientTickEvents.END_CLIENT_TICK.register(client -> {
			while (toggleHUDKey.method_1436()) {
				CultivationHUD.toggleHUD();
			}
		});
	}
}