package net.mcreator.sword.items;

import net.minecraft.class_1792;
import net.minecraft.class_1829;
import net.minecraft.class_1834;

public class CultivationBlade extends class_1829 {
    public CultivationBlade() {
        super(class_1834.field_22033, 3, -2.2F, new class_1792.class_1793());
    }
}
