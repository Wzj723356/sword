package net.mcreator.sword.items;

import net.minecraft.class_1792;
import net.minecraft.class_1829;
import net.minecraft.class_1834;

public class CultivationSword extends class_1829 {
    public CultivationSword() {
        super(class_1834.field_22033, 3, -2.4F, new class_1792.class_1793());
    }
}
