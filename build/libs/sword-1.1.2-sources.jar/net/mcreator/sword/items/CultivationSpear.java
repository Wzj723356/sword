package net.mcreator.sword.items;

import net.minecraft.class_1792;
import net.minecraft.class_1829;
import net.minecraft.class_1834;

public class CultivationSpear extends class_1829 {
    public CultivationSpear() {
        super(class_1834.field_22033, 4, -2.6F, new class_1792.class_1793());
    }
}
