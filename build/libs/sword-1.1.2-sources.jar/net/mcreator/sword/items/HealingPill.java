package net.mcreator.sword.items;

import net.minecraft.class_1268;
import net.minecraft.class_1271;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2561;

public class HealingPill extends class_1792 {
    public HealingPill() {
        super(new class_1792.class_1793().method_7889(64));
    }

    @Override
    public class_1271<class_1799> method_7836(class_1937 level, class_1657 player, class_1268 hand) {
        class_1799 stack = player.method_5998(hand);
        
        if (!level.field_9236) {
            player.method_6025(10.0F);
            player.method_7353(class_2561.method_43470("服用回血丹，恢复10点生命"), true);
            stack.method_7934(1);
        }
        
        return class_1271.method_22427(stack);
    }
}
