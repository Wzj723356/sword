/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.sword.init;

import net.mcreator.sword.SwordMod;
import net.mcreator.sword.DavoItem;
import net.mcreator.sword.DdsaItem;
import net.mcreator.sword.DavoHelmet;
import net.mcreator.sword.DavoChestplate;
import net.mcreator.sword.DavoLeggings;
import net.mcreator.sword.DavoBoots;
import net.mcreator.sword.DavoShield;
import net.mcreator.sword.items.CultivationStaff;
import net.mcreator.sword.init.SwordModBlocks;
import net.mcreator.sword.items.CultivationSword;
import net.mcreator.sword.items.CultivationBlade;
import net.mcreator.sword.items.CultivationSpear;
import net.mcreator.sword.items.LowGradeSpiritStone;
import net.mcreator.sword.items.MediumGradeSpiritStone;
import net.mcreator.sword.items.HighGradeSpiritStone;
import net.mcreator.sword.items.SupremeSpiritStone;
import net.mcreator.sword.items.HealingPill;
import net.mcreator.sword.items.SpiritGatheringPill;
import net.mcreator.sword.items.FoundationPill;
import net.mcreator.sword.items.SpiritualRootReforgingPill;
import net.mcreator.sword.items.FlyingSword;
import net.mcreator.sword.items.CloudBoatItem;
import net.mcreator.sword.items.TalismanPaper;
import net.minecraft.class_1747;
import net.minecraft.class_1792;
import net.minecraft.class_1802;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_5272;
import net.minecraft.class_6395;
import net.minecraft.class_7923;
import net.mcreator.sword.items.ArrayItem;
import net.mcreator.sword.items.MagicWandItem;

public class SwordModItems {
	public static class_1792 DAVO;
	public static class_1792 DDSA;
	public static class_1792 DAVO_HELMET;
	public static class_1792 DAVO_CHESTPLATE;
	public static class_1792 DAVO_LEGGINGS;
	public static class_1792 DAVO_BOOTS;
	public static class_1792 DAVO_SHIELD;
	public static class_1792 CULTIVATION_STAFF;
	public static class_1792 CULTIVATION_ARRAY;
	public static class_1792 CULTIVATION_SWORD;
	public static class_1792 CULTIVATION_BLADE;
	public static class_1792 CULTIVATION_SPEAR;
	public static class_1792 LOW_GRADE_SPIRIT_STONE;
	public static class_1792 MEDIUM_GRADE_SPIRIT_STONE;
	public static class_1792 HIGH_GRADE_SPIRIT_STONE;
	public static class_1792 SUPREME_SPIRIT_STONE;
	public static class_1792 HEALING_PILL;
	public static class_1792 SPIRIT_GATHERING_PILL;
	public static class_1792 FOUNDATION_PILL;
	public static class_1792 SPIRITUAL_ROOT_REFORGING_PILL;
	public static class_1792 FLYING_SWORD;
	public static class_1792 TRAINING_TARGET;
	public static class_1792 CLOUD_BOAT;
	public static class_1792 CULTIVATION_ARRAY_ITEM;
	public static class_1792 TELEPORT_ARRAY_ITEM;
	public static class_1792 ATTACK_ARRAY_ITEM;
	public static class_1792 HEALING_ARRAY_ITEM;
	public static class_1792 TRANSCENDENT_BREAK_WAND;
	public static class_1792 TRANSCENDENT_DETECT_WAND;
	public static class_1792 TRANSCENDENT_SEAL_WAND;
	public static class_1792 ATTACK_TALISMAN;
	public static class_1792 DEFENSE_TALISMAN;
	public static class_1792 HEALING_TALISMAN;
	public static class_1792 LIGHTNING_TALISMAN;
	public static class_1792 FIRE_TALISMAN;
	public static class_1792 ICE_TALISMAN;
	public static class_1792 WIND_TALISMAN;
	public static class_1792 TELEPORT_TALISMAN;

	public static void load() {
		DAVO = register("davo", new DavoItem());
		DDSA = register("ddsa", new DdsaItem());
		DAVO_HELMET = register("davo_helmet", new DavoHelmet());
		DAVO_CHESTPLATE = register("davo_chestplate", new DavoChestplate());
		DAVO_LEGGINGS = register("davo_leggings", new DavoLeggings());
		DAVO_BOOTS = register("davo_boots", new DavoBoots());
		DAVO_SHIELD = register("davo_shield", new DavoShield());
		CULTIVATION_STAFF = register("cultivation_staff", new CultivationStaff());
		CULTIVATION_ARRAY = register("cultivation_array", new class_1747(SwordModBlocks.CULTIVATION_ARRAY, new class_1792.class_1793()));
		CULTIVATION_SWORD = register("cultivation_sword", new CultivationSword());
		CULTIVATION_BLADE = register("cultivation_blade", new CultivationBlade());
		CULTIVATION_SPEAR = register("cultivation_spear", new CultivationSpear());
		LOW_GRADE_SPIRIT_STONE = register("low_grade_spirit_stone", new LowGradeSpiritStone());
		MEDIUM_GRADE_SPIRIT_STONE = register("medium_grade_spirit_stone", new MediumGradeSpiritStone());
		HIGH_GRADE_SPIRIT_STONE = register("high_grade_spirit_stone", new HighGradeSpiritStone());
		SUPREME_SPIRIT_STONE = register("supreme_spirit_stone", new SupremeSpiritStone());
		HEALING_PILL = register("healing_pill", new HealingPill());
		SPIRIT_GATHERING_PILL = register("spirit_gathering_pill", new SpiritGatheringPill());
		FOUNDATION_PILL = register("foundation_pill", new FoundationPill());
		SPIRITUAL_ROOT_REFORGING_PILL = register("spiritual_root_reforging_pill", new SpiritualRootReforgingPill());
		FLYING_SWORD = register("flying_sword", new FlyingSword());
		TRAINING_TARGET = register("training_target", new class_1747(SwordModBlocks.TRAINING_TARGET, new class_1792.class_1793()));
		CLOUD_BOAT = register("cloud_boat", new CloudBoatItem());
		CULTIVATION_ARRAY_ITEM = register("cultivation_array_item", new ArrayItem("cultivation", new class_1792.class_1793()));
		TELEPORT_ARRAY_ITEM = register("teleport_array_item", new ArrayItem("teleport", new class_1792.class_1793()));
		ATTACK_ARRAY_ITEM = register("attack_array_item", new ArrayItem("attack", new class_1792.class_1793()));
		HEALING_ARRAY_ITEM = register("healing_array_item", new ArrayItem("healing", new class_1792.class_1793()));
		TRANSCENDENT_BREAK_WAND = register("transcendent_break_wand", new MagicWandItem("break", new class_1792.class_1793().method_7889(1).method_7895(1)));
		TRANSCENDENT_DETECT_WAND = register("transcendent_detect_wand", new MagicWandItem("detect", new class_1792.class_1793().method_7889(1).method_7895(1)));
		TRANSCENDENT_SEAL_WAND = register("transcendent_seal_wand", new MagicWandItem("seal", new class_1792.class_1793().method_7889(1).method_7895(1)));
		ATTACK_TALISMAN = register("attack_talisman", new TalismanPaper(TalismanPaper.TalismanType.ATTACK));
		DEFENSE_TALISMAN = register("defense_talisman", new TalismanPaper(TalismanPaper.TalismanType.DEFENSE));
		HEALING_TALISMAN = register("healing_talisman", new TalismanPaper(TalismanPaper.TalismanType.HEALING));
		LIGHTNING_TALISMAN = register("lightning_talisman", new TalismanPaper(TalismanPaper.TalismanType.LIGHTNING));
		FIRE_TALISMAN = register("fire_talisman", new TalismanPaper(TalismanPaper.TalismanType.FIRE));
		ICE_TALISMAN = register("ice_talisman", new TalismanPaper(TalismanPaper.TalismanType.ICE));
		WIND_TALISMAN = register("wind_talisman", new TalismanPaper(TalismanPaper.TalismanType.WIND));
		TELEPORT_TALISMAN = register("teleport_talisman", new TalismanPaper(TalismanPaper.TalismanType.TELEPORT));
	}

	public static void clientLoad() {
	}

	private static class_1792 register(String registryName, class_1792 item) {
		return class_2378.method_10230(class_7923.field_41178, new class_2960(SwordMod.MODID, registryName), item);
	}

	private static void registerBlockingProperty(class_1792 item) {
		class_5272.method_27879(item, new class_2960("blocking"), (class_6395) class_5272.method_27878(class_1802.field_8255, new class_2960("blocking")));
		class_5272.method_27879(item, new class_2960("blocking"), (class_6395) class_5272.method_27878(class_1802.field_8255, new class_2960("blocking")));
	}
}