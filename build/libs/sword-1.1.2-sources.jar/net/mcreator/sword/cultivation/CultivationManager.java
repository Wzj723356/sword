package net.mcreator.sword.cultivation;

import net.mcreator.sword.SwordMod;
import net.minecraft.class_1657;
import net.minecraft.class_18;
import net.minecraft.class_1936;
import net.minecraft.class_2487;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class CultivationManager {
    private static final String CULTIVATION_DATA_KEY = SwordMod.MODID + ":cultivation_data";
    private static final String SAVED_DATA_NAME = SwordMod.MODID + ":cultivation_saved_data";

    public static class CultivationSavedData extends class_18 {
        private final Map<UUID, class_2487> playerData = new HashMap<>();

        public static CultivationSavedData load(class_2487 tag) {
            CultivationSavedData data = new CultivationSavedData();
            for (String key : tag.method_10541()) {
                data.playerData.put(UUID.fromString(key), tag.method_10562(key));
            }
            return data;
        }

        @Override
        public class_2487 method_75(class_2487 tag) {
            for (Map.Entry<UUID, class_2487> entry : playerData.entrySet()) {
                tag.method_10566(entry.getKey().toString(), entry.getValue());
            }
            return tag;
        }

        public class_2487 getPlayerData(UUID uuid) {
            return playerData.computeIfAbsent(uuid, k -> new class_2487());
        }

        public void setPlayerData(UUID uuid, class_2487 data) {
            playerData.put(uuid, data);
            method_80();
        }
    }

    private static CultivationSavedData getSavedData(class_1936 level) {
        if (level instanceof class_3218 serverLevel) {
            return serverLevel.method_17983().method_17924(
                CultivationSavedData::load,
                CultivationSavedData::new,
                SAVED_DATA_NAME
            );
        }
        return null;
    }

    public static CultivationData getCultivationData(class_1657 player) {
        CultivationSavedData savedData = getSavedData(player.method_37908());
        if (savedData == null) {
            CultivationData newData = new CultivationData();
            newData.setSpiritualRoot(SpiritualRoot.randomRoot(player.method_6051()));
            newData.setHasStartedCultivation(true);
            return newData;
        }

        class_2487 playerData = savedData.getPlayerData(player.method_5667());
        
        if (!playerData.method_10545(CULTIVATION_DATA_KEY)) {
            CultivationData newData = new CultivationData();
            newData.setSpiritualRoot(SpiritualRoot.randomRoot(player.method_6051()));
            newData.setHasStartedCultivation(true);
            playerData.method_10566(CULTIVATION_DATA_KEY, newData.toNBT());
            savedData.setPlayerData(player.method_5667(), playerData);
            return newData;
        }
        
        CultivationData data = new CultivationData();
        data.fromNBT(playerData.method_10562(CULTIVATION_DATA_KEY));
        if (!data.hasStartedCultivation() && data.getSpiritualRoot() != SpiritualRoot.NONE) {
            data.setHasStartedCultivation(true);
            saveCultivationData(player, data);
        }
        return data;
    }

    public static void saveCultivationData(class_1657 player, CultivationData data) {
        CultivationSavedData savedData = getSavedData(player.method_37908());
        if (savedData != null) {
            class_2487 playerData = savedData.getPlayerData(player.method_5667());
            playerData.method_10566(CULTIVATION_DATA_KEY, data.toNBT());
            savedData.setPlayerData(player.method_5667(), playerData);
        }
    }

    public static void addExperience(class_1657 player, int amount) {
        CultivationData data = getCultivationData(player);
        data.addExp(amount);
        saveCultivationData(player, data);
        
        if (player instanceof class_3222 serverPlayer) {
            syncToClient(serverPlayer);
        }
    }

    public static boolean checkLevelUp(class_1657 player) {
        CultivationData data = getCultivationData(player);
        boolean leveledUp = data.checkLevelUp();
        if (leveledUp) {
            saveCultivationData(player, data);
            if (player instanceof class_3222 serverPlayer) {
                syncToClient(serverPlayer);
            }
        }
        return leveledUp;
    }

    public static void syncToClient(class_3222 player) {
        net.mcreator.sword.network.CultivationPacketHandler.sendCultivationDataToClient(player);
    }
}
