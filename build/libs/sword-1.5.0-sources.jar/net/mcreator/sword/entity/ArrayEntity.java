package net.mcreator.sword.entity;

import java.util.List;
import net.mcreator.sword.cultivation.CultivationManager;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1588;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_238;
import net.minecraft.class_2398;
import net.minecraft.class_2561;
import net.minecraft.class_2940;
import net.minecraft.class_2943;
import net.minecraft.class_2945;
import net.minecraft.class_3218;

public class ArrayEntity extends class_1297 {
    private static final class_2940<String> DATA_ARRAY_TYPE = class_2945.method_12791(ArrayEntity.class, class_2943.field_13326);
    private static final class_2940<Boolean> DATA_SEALED = class_2945.method_12791(ArrayEntity.class, class_2943.field_13323);
    private static final class_2940<Integer> DATA_CORE_HEALTH = class_2945.method_12791(ArrayEntity.class, class_2943.field_13327);
    
    private int tickCounter = 0;

    public ArrayEntity(class_1299<? extends ArrayEntity> entityType, class_1937 level) {
        super(entityType, level);
        this.field_5960 = true;
        this.field_23807 = false;
    }

    public ArrayEntity(class_1937 level, double x, double y, double z, String arrayType) {
        this(net.mcreator.sword.init.SwordModEntities.ARRAY, level);
        this.method_5814(x, y, z);
        this.setArrayType(arrayType);
        this.setSealed(false);
        this.setCoreHealth(100);
    }

    @Override
    protected void method_5693() {
        this.field_6011.method_12784(DATA_ARRAY_TYPE, "cultivation");
        this.field_6011.method_12784(DATA_SEALED, false);
        this.field_6011.method_12784(DATA_CORE_HEALTH, 100);
    }

    @Override
    public void method_5773() {
        super.method_5773();
        tickCounter++;
        
        if (!this.method_37908().field_9236) {
            
        } else {
            if (this.method_37908() != null && tickCounter % 2 == 0) {
                spawnArrayParticles();
            }
        }
    }

    private void spawnArrayParticles() {
        String arrayType = this.getArrayType();
        double centerX = this.method_23317();
        double centerY = this.method_23318();
        double centerZ = this.method_23321();
        boolean sealed = this.isSealed();
        
        if (arrayType == null) {
            return;
        }
        
        if (sealed) {
            spawnSealedParticles(centerX, centerY, centerZ);
            return;
        }
        
        switch (arrayType) {
            case "cultivation":
                spawnCultivationParticles(centerX, centerY, centerZ);
                break;
            case "teleport":
                spawnTeleportParticles(centerX, centerY, centerZ);
                break;
            case "attack":
                spawnAttackParticles(centerX, centerY, centerZ);
                break;
            case "healing":
                spawnHealingParticles(centerX, centerY, centerZ);
                break;
        }
        
        spawnCoreParticles(centerX, centerY, centerZ);
    }

    private void spawnSealedParticles(double x, double y, double z) {
        if (this.method_37908() == null) return;
        
        for (int i = 0; i < 5; i++) {
            double angle = (i * 2 * Math.PI / 5) + (tickCounter * 0.02);
            double radius = 2.0;
            double px = x + Math.cos(angle) * radius;
            double pz = z + Math.sin(angle) * radius;
            
            method_37908().method_8406(class_2398.field_11220, px, y + 0.1, pz, 0, 0.03, 0);
        }
        
        if (tickCounter % 6 == 0) {
            method_37908().method_8406(class_2398.field_11215,
                x + (method_37908().field_9229.method_43058() - 0.5) * 2.0,
                y + 0.5 + method_37908().field_9229.method_43058() * 1.0,
                z + (method_37908().field_9229.method_43058() - 0.5) * 2.0,
                0, 0.02, 0);
        }
    }

    private void spawnCoreParticles(double x, double y, double z) {
        if (this.method_37908() == null) return;
        
        int health = this.getCoreHealth();
        double coreSize = 0.3 + (health / 100.0) * 0.5;
        
        for (int i = 0; i < 2; i++) {
            double angle = method_37908().field_9229.method_43058() * Math.PI * 2;
            double radius = coreSize * method_37908().field_9229.method_43058();
            double px = x + Math.cos(angle) * radius;
            double pz = z + Math.sin(angle) * radius;
            
            method_37908().method_8406(class_2398.field_11207, px, y + 0.5, pz, 0, 0.05, 0);
        }
        
        if (tickCounter % 40 == 0) {
            method_37908().method_8406(class_2398.field_17909, x, y + 0.5, z, 0, 0, 0);
        }
    }

    private void spawnCultivationParticles(double x, double y, double z) {
        if (this.method_37908() == null) return;
        
        double radius = 2.0;
        int segments = 6;
        
        for (int i = 0; i < segments; i++) {
            double angle = (i * 2 * Math.PI / segments) + (tickCounter * 0.02);
            double px = x + Math.cos(angle) * radius;
            double pz = z + Math.sin(angle) * radius;
            
            method_37908().method_8406(class_2398.field_11207, px, y + 0.1, pz, 0, 0.03, 0);
        }
        
        for (int ring = 1; ring <= 2; ring++) {
            double ringRadius = radius * ring / 2;
            for (int i = 0; i < segments * ring; i++) {
                double angle = (i * 2 * Math.PI / (segments * ring)) - (tickCounter * 0.01 * ring);
                double px = x + Math.cos(angle) * ringRadius;
                double pz = z + Math.sin(angle) * ringRadius;
                
                method_37908().method_8406(class_2398.field_11207, px, y + 0.1, pz, 0, 0.02, 0);
            }
        }
        
        if (tickCounter % 6 == 0) {
            method_37908().method_8406(class_2398.field_11215, 
                x + (method_37908().field_9229.method_43058() - 0.5) * 3,
                y + 0.2 + method_37908().field_9229.method_43058() * 0.5,
                z + (method_37908().field_9229.method_43058() - 0.5) * 3,
                0, 0.02, 0);
        }
    }

    private void spawnTeleportParticles(double x, double y, double z) {
        if (this.method_37908() == null) return;
        
        double radius = 2.5;
        int segments = 8;
        
        for (int i = 0; i < segments; i++) {
            double angle = (i * 2 * Math.PI / segments) + (tickCounter * 0.03);
            double px = x + Math.cos(angle) * radius;
            double pz = z + Math.sin(angle) * radius;
            
            method_37908().method_8406(class_2398.field_11214, px, y + 0.1, pz, 0, 0.05, 0);
        }
        
        if (tickCounter % 10 == 0) {
            method_37908().method_8406(class_2398.field_11214, x, y + 0.5, z, 0, 0.1, 0);
        }
    }

    private void spawnAttackParticles(double x, double y, double z) {
        if (this.method_37908() == null) return;
        
        double radius = 2.0;
        int segments = 4;
        
        for (int i = 0; i < segments; i++) {
            double angle = (i * 2 * Math.PI / segments) + (tickCounter * 0.04);
            double px = x + Math.cos(angle) * radius;
            double pz = z + Math.sin(angle) * radius;
            
            method_37908().method_8406(class_2398.field_11240, px, y + 0.1, pz, 0, 0.05, 0);
        }
        
        if (tickCounter % 8 == 0) {
            method_37908().method_8406(class_2398.field_11239, x, y + 0.3, z, 0, 0.02, 0);
        }
    }

    private void spawnHealingParticles(double x, double y, double z) {
        if (this.method_37908() == null) return;
        
        double radius = 2.0;
        int segments = 6;
        
        for (int i = 0; i < segments; i++) {
            double angle = (i * 2 * Math.PI / segments) + (tickCounter * 0.025);
            double px = x + Math.cos(angle) * radius;
            double pz = z + Math.sin(angle) * radius;
            
            method_37908().method_8406(class_2398.field_11201, px, y + 0.1, pz, 0, 0.05, 0);
        }
        
        if (tickCounter % 8 == 0) {
            method_37908().method_8406(class_2398.field_11220, x, y + 0.5, z, 0, 0.02, 0);
        }
    }

    @Override
    public boolean method_5643(net.minecraft.class_1282 source, float amount) {
        if (this.method_37908().field_9236) {
            return false;
        }
        
        if (this.isSealed()) {
            if (source.method_5529() instanceof class_1657 player) {
                player.method_7353(class_2561.method_43470("法阵已被封印，无法破坏！"), true);
            }
            return false;
        }
        
        if (source.method_5529() instanceof class_1657) {
            int currentHealth = this.getCoreHealth();
            this.setCoreHealth(Math.max(0, currentHealth - (int) amount));
            
            if (source.method_5529() instanceof class_1657 player) {
                player.method_7353(class_2561.method_43470("攻击阵眼！阵眼生命值：" + this.getCoreHealth() + "/100"), true);
            }
            
            if (this.method_37908() instanceof class_3218 serverLevel) {
                for (int i = 0; i < 20; i++) {
                    serverLevel.method_14199(class_2398.field_11205,
                        this.method_23317() + (this.method_37908().field_9229.method_43058() - 0.5) * 1.0,
                        this.method_23318() + 0.5 + this.method_37908().field_9229.method_43058() * 0.5,
                        this.method_23321() + (this.method_37908().field_9229.method_43058() - 0.5) * 1.0,
                        1, 0, 0.1, 0, 0);
                }
            }
            
            if (this.getCoreHealth() <= 0) {
                this.method_31472();
                if (source.method_5529() instanceof class_1657 player) {
                    player.method_7353(class_2561.method_43470("阵眼已被破坏，法阵破除！"), true);
                }
                
                if (this.method_37908() instanceof class_3218 serverLevel) {
                    for (int i = 0; i < 100; i++) {
                        serverLevel.method_14199(class_2398.field_11236,
                            this.method_23317() + (this.method_37908().field_9229.method_43058() - 0.5) * 3.0,
                            this.method_23318() + 0.5 + this.method_37908().field_9229.method_43058() * 1.0,
                            this.method_23321() + (this.method_37908().field_9229.method_43058() - 0.5) * 3.0,
                            1, 0, 0.1, 0, 0);
                    }
                    
                    for (int i = 0; i < 80; i++) {
                        serverLevel.method_14199(class_2398.field_11251,
                            this.method_23317() + (this.method_37908().field_9229.method_43058() - 0.5) * 4.0,
                            this.method_23318() + 0.5 + this.method_37908().field_9229.method_43058() * 1.5,
                            this.method_23321() + (this.method_37908().field_9229.method_43058() - 0.5) * 4.0,
                            1, 0, 0.05, 0, 0);
                    }
                }
            }
            return true;
        }
        return false;
    }

    @Override
    public class_1269 method_5688(class_1657 player, class_1268 hand) {
        if (!this.method_37908().field_9236 && player != null) {
            String arrayType = this.getArrayType();
            
            if (arrayType == null) {
                return class_1269.field_5814;
            }
            
            switch (arrayType) {
                case "cultivation":
                    CultivationManager.addExperience(player, 50);
                    if (CultivationManager.checkLevelUp(player)) {
                        player.method_7353(class_2561.method_43470("阵法修炼！境界提升！当前境界：" + CultivationManager.getCultivationData(player).getRealm().getDisplayName()), true);
                    }
                    triggerCultivationEffect();
                    break;
                    
                case "teleport":
                    teleportPlayer(player);
                    break;
                    
                case "attack":
                    triggerAttackEffect(player);
                    break;
                    
                case "healing":
                    triggerHealingEffect(player);
                    break;
            }
        }
        
        return class_1269.field_5812;
    }

    private void triggerCultivationEffect() {
        if (this.method_37908() instanceof class_3218 serverLevel) {
            for (int i = 0; i < 30; i++) {
                double angle = i * Math.PI * 2 / 30;
                double radius = 3.0;
                double x = this.method_23317() + Math.cos(angle) * radius;
                double z = this.method_23321() + Math.sin(angle) * radius;
                
                serverLevel.method_14199(class_2398.field_11207, x, this.method_23318() + 0.5, z, 1, 0, 0.1, 0, 0.02);
            }
            
            for (int i = 0; i < 15; i++) {
                serverLevel.method_14199(class_2398.field_11215,
                    this.method_23317() + (this.method_37908().field_9229.method_43058() - 0.5) * 4.0,
                    this.method_23318() + 0.5 + this.method_37908().field_9229.method_43058() * 2.0,
                    this.method_23321() + (this.method_37908().field_9229.method_43058() - 0.5) * 4.0,
                    1, 0, 0.1, 0, 0);
            }
        }
    }

    private void teleportPlayer(class_1657 player) {
        if (player == null) return;
        
        class_238 searchBox = new class_238(this.method_24515()).method_1014(50.0);
        ArrayEntity targetArray = null;
        
        for (class_1297 entity : this.method_37908().method_18467(ArrayEntity.class, searchBox)) {
            if (entity instanceof ArrayEntity array && array != this && array.getArrayType() != null && array.getArrayType().equals("teleport")) {
                targetArray = array;
                break;
            }
        }
        
        if (targetArray != null) {
            player.method_5859(targetArray.method_23317(), targetArray.method_23318() + 1.0, targetArray.method_23321());
            player.method_7353(class_2561.method_43470("传送成功！"), true);
            
            if (this.method_37908() instanceof class_3218 serverLevel) {
                for (int i = 0; i < 20; i++) {
                    serverLevel.method_14199(class_2398.field_11214,
                        targetArray.method_23317() + (this.method_37908().field_9229.method_43058() - 0.5) * 3.0,
                        targetArray.method_23318() + 1.0 + this.method_37908().field_9229.method_43058() * 2.0,
                        targetArray.method_23321() + (this.method_37908().field_9229.method_43058() - 0.5) * 3.0,
                        1, 0, 0.1, 0, 0);
                }
            }
        } else {
            player.method_7353(class_2561.method_43470("没有找到其他传送阵！"), true);
        }
    }

    private void triggerAttackEffect(class_1657 player) {
        if (player == null) return;
        
        if (this.method_37908() instanceof class_3218 serverLevel) {
            var enemies = this.method_37908().method_18467(net.minecraft.class_1588.class, new class_238(this.method_24515()).method_1014(10.0));
            
            if (enemies.isEmpty()) {
                return;
            }
            
            int damageCount = 0;
            for (var enemy : enemies) {
                enemy.method_5643(this.method_37908().method_48963().method_48802(player), 20.0F);
                damageCount++;
                
                for (int i = 0; i < 5; i++) {
                    serverLevel.method_14199(class_2398.field_11216,
                        enemy.method_23317(),
                        enemy.method_23318() + enemy.method_17682() / 2,
                        enemy.method_23321(),
                        1, 0, 0, 0, 0.05);
                }
            }
            
            for (int i = 0; i < 30; i++) {
                double angle = i * Math.PI * 2 / 30;
                double radius = 3.5;
                double x = this.method_23317() + Math.cos(angle) * radius;
                double z = this.method_23321() + Math.sin(angle) * radius;
                
                serverLevel.method_14199(class_2398.field_11240, x, this.method_23318() + 0.5, z, 1, 0, 0.1, 0, 0.02);
            }
        }
    }

    private void triggerHealingEffect(class_1657 player) {
        if (player == null) return;
        
        if (this.method_37908() instanceof class_3218 serverLevel) {
            var entities = this.method_37908().method_18467(net.minecraft.class_1309.class, new class_238(this.method_24515()).method_1014(15.0));
            
            if (entities.isEmpty()) {
                return;
            }
            
            int healCount = 0;
            for (var entity : entities) {
                entity.method_6025(20.0F);
                entity.method_6092(new net.minecraft.class_1293(
                    net.minecraft.class_1294.field_5924, 300, 2, false, false));
                healCount++;
                
                for (int i = 0; i < 5; i++) {
                    serverLevel.method_14199(class_2398.field_11201,
                        entity.method_23317() + (this.method_37908().field_9229.method_43058() - 0.5) * 1.0,
                        entity.method_23318() + entity.method_17682() + 0.5,
                        entity.method_23321() + (this.method_37908().field_9229.method_43058() - 0.5) * 1.0,
                        1, 0, 0.1, 0, 0);
                }
            }
            
            for (int i = 0; i < 20; i++) {
                double angle = i * Math.PI * 2 / 20;
                double radius = 3.0;
                double x = this.method_23317() + Math.cos(angle) * radius;
                double z = this.method_23321() + Math.sin(angle) * radius;
                
                serverLevel.method_14199(class_2398.field_11201, x, this.method_23318() + 0.5, z, 1, 0, 0.05, 0, 0);
            }
        }
    }

    public String getArrayType() {
        return this.field_6011.method_12789(DATA_ARRAY_TYPE);
    }

    public void setArrayType(String type) {
        this.field_6011.method_12778(DATA_ARRAY_TYPE, type);
    }

    public boolean isSealed() {
        return this.field_6011.method_12789(DATA_SEALED);
    }

    public void setSealed(boolean sealed) {
        this.field_6011.method_12778(DATA_SEALED, sealed);
    }

    public int getCoreHealth() {
        return this.field_6011.method_12789(DATA_CORE_HEALTH);
    }

    public void setCoreHealth(int health) {
        this.field_6011.method_12778(DATA_CORE_HEALTH, health);
    }

    @Override
    protected void method_5749(net.minecraft.class_2487 compound) {
        this.setArrayType(compound.method_10558("ArrayType"));
        this.setSealed(compound.method_10577("Sealed"));
        this.setCoreHealth(compound.method_10550("CoreHealth"));
    }

    @Override
    protected void method_5652(net.minecraft.class_2487 compound) {
        compound.method_10582("ArrayType", this.getArrayType());
        compound.method_10556("Sealed", this.isSealed());
        compound.method_10569("CoreHealth", this.getCoreHealth());
    }
}