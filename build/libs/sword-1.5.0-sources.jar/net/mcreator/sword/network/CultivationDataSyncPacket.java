package net.mcreator.sword.network;

import net.mcreator.sword.SwordMod;
import net.mcreator.sword.cultivation.CultivationData;
import net.mcreator.sword.cultivation.CultivationRealm;
import net.mcreator.sword.cultivation.SpiritualRoot;
import net.minecraft.class_2540;
import net.minecraft.class_2960;
import java.util.Set;
import java.util.HashSet;

public class CultivationDataSyncPacket implements CultivationPacket {
    private final String realmName;
    private final int currentExp;
    private final String rootName;
    private final boolean hasStartedCultivation;
    private final int spiritualPower;
    private final int maxSpiritualPower;
    private final Set<String> learnedSkills;
    
    public CultivationDataSyncPacket(CultivationData data) {
        this.realmName = data.getRealm().name();
        this.currentExp = data.getCurrentExp();
        this.rootName = data.getSpiritualRoot().name();
        this.hasStartedCultivation = data.hasStartedCultivation();
        this.spiritualPower = data.getSpiritualPower();
        this.maxSpiritualPower = data.getMaxSpiritualPower();
        this.learnedSkills = data.getLearnedSkills();
    }
    
    public CultivationDataSyncPacket(class_2540 buffer) {
        this.realmName = buffer.method_19772();
        this.currentExp = buffer.readInt();
        this.rootName = buffer.method_19772();
        this.hasStartedCultivation = buffer.readBoolean();
        this.spiritualPower = buffer.readInt();
        this.maxSpiritualPower = buffer.readInt();
        int skillCount = buffer.readInt();
        this.learnedSkills = new HashSet<>();
        for (int i = 0; i < skillCount; i++) {
            this.learnedSkills.add(buffer.method_19772());
        }
    }
    
    @Override
    public void encode(class_2540 buffer) {
        buffer.method_10814(realmName);
        buffer.writeInt(currentExp);
        buffer.method_10814(rootName);
        buffer.writeBoolean(hasStartedCultivation);
        buffer.writeInt(spiritualPower);
        buffer.writeInt(maxSpiritualPower);
        buffer.writeInt(learnedSkills.size());
        for (String skill : learnedSkills) {
            buffer.method_10814(skill);
        }
    }
    
    @Override
    public void handle(Context context) {
        CultivationData data = new CultivationData();
        data.setRealm(CultivationRealm.valueOf(realmName));
        data.setCurrentExp(currentExp);
        data.setSpiritualRoot(SpiritualRoot.valueOf(rootName));
        data.setHasStartedCultivation(hasStartedCultivation);
        data.setMaxSpiritualPower(maxSpiritualPower);
        data.setSpiritualPower(spiritualPower);
        for (String skill : learnedSkills) {
            data.getLearnedSkills().add(skill);
        }
        
        CultivationDataCache.setCachedData(data);
    }
    
    @Override
    public class_2960 getId() {
        return new class_2960(SwordMod.MODID, "cultivation_data_sync");
    }
    
    public CultivationData getData() {
        CultivationData data = new CultivationData();
        data.setRealm(CultivationRealm.valueOf(realmName));
        data.setCurrentExp(currentExp);
        data.setSpiritualRoot(SpiritualRoot.valueOf(rootName));
        data.setHasStartedCultivation(hasStartedCultivation);
        data.setMaxSpiritualPower(maxSpiritualPower);
        data.setSpiritualPower(spiritualPower);
        for (String skill : learnedSkills) {
            data.getLearnedSkills().add(skill);
        }
        return data;
    }
}