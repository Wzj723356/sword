package net.mcreator.sword.cultivation;

import org.joml.Vector3f;
import net.mcreator.sword.cultivation.CultivationManager;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_238;
import net.minecraft.class_2390;
import net.minecraft.class_2398;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.mcreator.sword.cultivation.CultivationData;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class SkillManager {
    private static final Map<UUID, Map<CultivationTechnique, Integer>> cooldowns = new HashMap<>();
    private static final Map<UUID, Integer> shieldTimers = new HashMap<>();
    private static final Map<UUID, Integer> defenseBoostTimers = new HashMap<>();
    private static final Map<UUID, Integer> damageBoostTimers = new HashMap<>();

    public static boolean canUseSkill(class_1657 player, CultivationTechnique technique) {
        if (!technique.isActiveSkill()) return false;
        
        CultivationData data = CultivationManager.getCultivationData(player);
        if (!data.hasStartedCultivation()) return false;
        
        if (data.getSpiritualPower() < technique.getSpiritualPowerCost()) {
            player.method_7353(class_2561.method_43470("灵力不足！需要 " + technique.getSpiritualPowerCost() + " 点灵力"), true);
            return false;
        }
        
        if (isOnCooldown(player, technique)) {
            int remainingCooldown = getRemainingCooldown(player, technique);
            player.method_7353(class_2561.method_43470("技能冷却中！还需 " + (remainingCooldown / 20) + " 秒"), true);
            return false;
        }
        
        return true;
    }

    public static void useSkill(class_1657 player, CultivationTechnique technique) {
        if (!canUseSkill(player, technique)) return;
        
        CultivationData data = CultivationManager.getCultivationData(player);
        class_1937 level = player.method_37908();
        
        data.consumeSpiritualPower(technique.getSpiritualPowerCost());
        CultivationManager.saveCultivationData(player, data);
        
        setCooldown(player, technique, technique.getCooldownTicks());
        
        switch (technique) {
            case FIRE_BALL:
                castFireBall(player, level);
                break;
            case ICE_SHARD:
                castIceShard(player, level);
                break;
            case LIGHTNING_BOLT:
                castLightningBolt(player, level);
                break;
            case WIND_BLADE:
                castWindBlade(player, level);
                break;
            case EARTH_SPIKE:
                castEarthSpike(player, level);
                break;
            case HEALING_LIGHT:
                castHealingLight(player, level);
                break;
            case SHIELD_BARRIER:
                castShieldBarrier(player, level);
                break;
            case TELEPORT:
                castTeleport(player, level);
                break;
            case FLYING_SWORD:
                castFlyingSword(player, level);
                break;
            case ELEMENTAL_BURST:
                castElementalBurst(player, level);
                break;
            case SPIRITUAL_AURA:
                castSpiritualAura(player, level);
                break;
            case BODY_FORTIFICATION:
                castBodyFortification(player, level);
                break;
            case SOUL_RESONANCE:
                castSoulResonance(player, level);
                break;
            case TIME_DILATION:
                castTimeDilation(player, level);
                break;
            default:
                break;
        }
        
        if (player instanceof class_3222 serverPlayer) {
            CultivationManager.syncToClient(serverPlayer);
        }
    }

    private static void castFireBall(class_1657 player, class_1937 level) {
        class_243 lookVec = player.method_5720();
        class_243 startPos = player.method_33571().method_1019(lookVec.method_1021(1.5));
        
        for (int i = 0; i < 20; i++) {
            class_243 pos = startPos.method_1019(lookVec.method_1021(i * 0.5));
            level.method_8406(class_2398.field_11240, pos.field_1352, pos.field_1351, pos.field_1350, 0, 0, 0);
        }
        
        class_243 hitPos = startPos.method_1019(lookVec.method_1021(10));
        class_238 area = new class_238(hitPos.field_1352 - 3, hitPos.field_1351 - 3, hitPos.field_1350 - 3, 
                           hitPos.field_1352 + 3, hitPos.field_1351 + 3, hitPos.field_1350 + 3);
        
        for (class_1297 entity : level.method_18467(class_1309.class, area)) {
            if (entity != player) {
                entity.method_5643(level.method_48963().method_48802(player), 8.0F);
                entity.method_5639(3);
            }
        }
        
        level.method_8396(null, player.method_24515(), class_3417.field_15013, class_3419.field_15248, 1.0F, 1.0F);
    }

    private static void castIceShard(class_1657 player, class_1937 level) {
        class_243 lookVec = player.method_5720();
        class_243 startPos = player.method_33571().method_1019(lookVec.method_1021(1.5));
        
        for (int i = 0; i < 15; i++) {
            class_243 pos = startPos.method_1019(lookVec.method_1021(i * 0.5));
            level.method_8406(class_2398.field_28013, pos.field_1352, pos.field_1351, pos.field_1350, 0, 0, 0);
        }
        
        class_243 hitPos = startPos.method_1019(lookVec.method_1021(8));
        class_238 area = new class_238(hitPos.field_1352 - 2, hitPos.field_1351 - 2, hitPos.field_1350 - 2, 
                           hitPos.field_1352 + 2, hitPos.field_1351 + 2, hitPos.field_1350 + 2);
        
        for (class_1297 entity : level.method_18467(class_1309.class, area)) {
            if (entity != player) {
                entity.method_5643(level.method_48963().method_48802(player), 6.0F);
                if (entity instanceof class_1309 livingEntity) {
                    livingEntity.method_6092(new class_1293(class_1294.field_5909, 60, 2));
                }
            }
        }
        
        level.method_8396(null, player.method_24515(), class_3417.field_15081, class_3419.field_15248, 1.0F, 1.0F);
    }

    private static void castLightningBolt(class_1657 player, class_1937 level) {
        class_243 lookVec = player.method_5720();
        class_243 hitPos = player.method_33571().method_1019(lookVec.method_1021(12));
        
        for (int i = 0; i < 30; i++) {
            double x = hitPos.field_1352 + (Math.random() - 0.5) * 6;
            double z = hitPos.field_1350 + (Math.random() - 0.5) * 6;
            level.method_8406(class_2398.field_29644, x, hitPos.field_1351, z, 0, 0, 0);
        }
        
        class_238 area = new class_238(hitPos.field_1352 - 4, hitPos.field_1351 - 4, hitPos.field_1350 - 4, 
                           hitPos.field_1352 + 4, hitPos.field_1351 + 4, hitPos.field_1350 + 4);
        
        for (class_1297 entity : level.method_18467(class_1309.class, area)) {
            if (entity != player) {
                entity.method_5643(level.method_48963().method_48802(player), 10.0F);
            }
        }
        
        level.method_8396(null, player.method_24515(), class_3417.field_14865, class_3419.field_15248, 1.0F, 1.0F);
    }

    private static void castWindBlade(class_1657 player, class_1937 level) {
        class_243 lookVec = player.method_5720();
        class_243 startPos = player.method_33571().method_1019(lookVec.method_1021(1.5));
        
        for (int i = 0; i < 25; i++) {
            class_243 pos = startPos.method_1019(lookVec.method_1021(i * 0.6));
            level.method_8406(class_2398.field_11227, pos.field_1352, pos.field_1351, pos.field_1350, 0, 0, 0);
        }
        
        class_243 hitPos = startPos.method_1019(lookVec.method_1021(15));
        class_238 area = new class_238(hitPos.field_1352 - 2, hitPos.field_1351 - 2, hitPos.field_1350 - 2, 
                           hitPos.field_1352 + 2, hitPos.field_1351 + 2, hitPos.field_1350 + 2);
        
        for (class_1297 entity : level.method_18467(class_1309.class, area)) {
            if (entity != player) {
                entity.method_5643(level.method_48963().method_48802(player), 7.0F);
            }
        }
        
        level.method_8396(null, player.method_24515(), class_3417.field_26980, class_3419.field_15248, 1.0F, 1.0F);
    }

    private static void castEarthSpike(class_1657 player, class_1937 level) {
        class_243 lookVec = player.method_5720();
        class_243 hitPos = player.method_33571().method_1019(lookVec.method_1021(10));
        
        for (int i = 0; i < 20; i++) {
            double x = hitPos.field_1352 + (Math.random() - 0.5) * 5;
            double z = hitPos.field_1350 + (Math.random() - 0.5) * 5;
            class_2390 dustOptions = new class_2390(new Vector3f(0.8F, 0.8F, 0.8F), 1.0F);
            level.method_8406(dustOptions, x, hitPos.field_1351, z, 0, 1, 0);
        }
        
        class_238 area = new class_238(hitPos.field_1352 - 3, hitPos.field_1351 - 3, hitPos.field_1350 - 3, 
                           hitPos.field_1352 + 3, hitPos.field_1351 + 3, hitPos.field_1350 + 3);
        
        for (class_1297 entity : level.method_18467(class_1309.class, area)) {
            if (entity != player) {
                entity.method_5643(level.method_48963().method_48802(player), 9.0F);
            }
        }
        
        level.method_8396(null, player.method_24515(), class_3417.field_15211, class_3419.field_15248, 1.0F, 1.0F);
    }

    private static void castHealingLight(class_1657 player, class_1937 level) {
        player.method_6025(15.0F);
        
        for (int i = 0; i < 30; i++) {
            double x = player.method_23317() + (Math.random() - 0.5) * 2;
            double y = player.method_23318() + Math.random() * 2;
            double z = player.method_23321() + (Math.random() - 0.5) * 2;
            level.method_8406(class_2398.field_11201, x, y, z, 0, 0.1, 0);
        }
        
        level.method_8396(null, player.method_24515(), class_3417.field_26980, class_3419.field_15248, 1.0F, 1.0F);
    }

    private static void castShieldBarrier(class_1657 player, class_1937 level) {
        shieldTimers.put(player.method_5667(), 200);
        
        for (int i = 0; i < 40; i++) {
            double angle = (i / 40.0) * Math.PI * 2;
            double x = player.method_23317() + Math.cos(angle) * 1.5;
            double z = player.method_23321() + Math.sin(angle) * 1.5;
            level.method_8406(class_2398.field_11220, x, player.method_23318() + 1, z, 0, 0, 0);
        }
        
        level.method_8396(null, player.method_24515(), class_3417.field_14931, class_3419.field_15248, 1.0F, 1.0F);
    }

    private static void castTeleport(class_1657 player, class_1937 level) {
        class_243 lookVec = player.method_5720();
        class_243 newPos = player.method_33571().method_1019(lookVec.method_1021(8));
        
        for (int i = 0; i < 20; i++) {
            double x = player.method_23317() + (Math.random() - 0.5) * 2;
            double y = player.method_23318() + Math.random() * 2;
            double z = player.method_23321() + (Math.random() - 0.5) * 2;
            level.method_8406(class_2398.field_11214, x, y, z, 0, 0, 0);
        }
        
        player.method_5859(newPos.field_1352, newPos.field_1351, newPos.field_1350);
        
        for (int i = 0; i < 20; i++) {
            double x = player.method_23317() + (Math.random() - 0.5) * 2;
            double y = player.method_23318() + Math.random() * 2;
            double z = player.method_23321() + (Math.random() - 0.5) * 2;
            level.method_8406(class_2398.field_11214, x, y, z, 0, 0, 0);
        }
        
        level.method_8396(null, player.method_24515(), class_3417.field_14879, class_3419.field_15248, 1.0F, 1.0F);
    }

    private static void castFlyingSword(class_1657 player, class_1937 level) {
        player.method_18799(player.method_5720().method_1021(1.5));
        
        for (int i = 0; i < 30; i++) {
            class_243 pos = player.method_33571().method_1019(player.method_5720().method_1021(i * 0.3));
            level.method_8406(class_2398.field_11227, pos.field_1352, pos.field_1351, pos.field_1350, 0, 0, 0);
        }
        
        level.method_8396(null, player.method_24515(), class_3417.field_14706, class_3419.field_15248, 1.0F, 1.0F);
    }

    private static void castElementalBurst(class_1657 player, class_1937 level) {
        class_243 lookVec = player.method_5720();
        class_243 hitPos = player.method_33571().method_1019(lookVec.method_1021(15));
        
        for (int i = 0; i < 50; i++) {
            double x = hitPos.field_1352 + (Math.random() - 0.5) * 8;
            double y = hitPos.field_1351 + (Math.random() - 0.5) * 8;
            double z = hitPos.field_1350 + (Math.random() - 0.5) * 8;
            level.method_8406(class_2398.field_11236, x, y, z, 0, 0, 0);
        }
        
        class_238 area = new class_238(hitPos.field_1352 - 5, hitPos.field_1351 - 5, hitPos.field_1350 - 5, 
                           hitPos.field_1352 + 5, hitPos.field_1351 + 5, hitPos.field_1350 + 5);
        
        for (class_1297 entity : level.method_18467(class_1309.class, area)) {
            if (entity != player) {
                entity.method_5643(level.method_48963().method_48802(player), 15.0F);
                entity.method_5639(5);
            }
        }
        
        level.method_8396(null, player.method_24515(), class_3417.field_15152, class_3419.field_15248, 1.0F, 1.0F);
    }

    private static void castSpiritualAura(class_1657 player, class_1937 level) {
        damageBoostTimers.put(player.method_5667(), 300);
        
        for (int i = 0; i < 25; i++) {
            double angle = (i / 25.0) * Math.PI * 2;
            double x = player.method_23317() + Math.cos(angle) * 2;
            double z = player.method_23321() + Math.sin(angle) * 2;
            level.method_8406(class_2398.field_11215, x, player.method_23318() + 1, z, 0, 0.1, 0);
        }
        
        level.method_8396(null, player.method_24515(), class_3417.field_15119, class_3419.field_15248, 1.0F, 1.0F);
    }

    private static void castBodyFortification(class_1657 player, class_1937 level) {
        defenseBoostTimers.put(player.method_5667(), 225);
        
        for (int i = 0; i < 20; i++) {
            double x = player.method_23317() + (Math.random() - 0.5) * 2;
            double y = player.method_23318() + Math.random() * 2;
            double z = player.method_23321() + (Math.random() - 0.5) * 2;
            level.method_8406(class_2398.field_11209, x, y, z, 0, 0.1, 0);
        }
        
        level.method_8396(null, player.method_24515(), class_3417.field_14559, class_3419.field_15248, 1.0F, 1.0F);
    }

    private static void castSoulResonance(class_1657 player, class_1937 level) {
        damageBoostTimers.put(player.method_5667(), 600);
        
        for (int i = 0; i < 40; i++) {
            double angle = (i / 40.0) * Math.PI * 2;
            double x = player.method_23317() + Math.cos(angle) * 2.5;
            double z = player.method_23321() + Math.sin(angle) * 2.5;
            level.method_8406(class_2398.field_11245, x, player.method_23318() + 1, z, 0, 0.1, 0);
        }
        
        level.method_8396(null, player.method_24515(), class_3417.field_14858, class_3419.field_15248, 1.0F, 1.0F);
    }

    private static void castTimeDilation(class_1657 player, class_1937 level) {
        class_243 lookVec = player.method_5720();
        class_243 hitPos = player.method_33571().method_1019(lookVec.method_1021(10));
        
        for (int i = 0; i < 60; i++) {
            double x = hitPos.field_1352 + (Math.random() - 0.5) * 10;
            double y = hitPos.field_1351 + (Math.random() - 0.5) * 10;
            double z = hitPos.field_1350 + (Math.random() - 0.5) * 10;
            level.method_8406(class_2398.field_11207, x, y, z, 0, 0, 0);
        }
        
        class_238 area = new class_238(hitPos.field_1352 - 6, hitPos.field_1351 - 6, hitPos.field_1350 - 6, 
                           hitPos.field_1352 + 6, hitPos.field_1351 + 6, hitPos.field_1350 + 6);
        
        for (class_1297 entity : level.method_18467(class_1309.class, area)) {
            if (entity != player) {
                if (entity instanceof class_1309 livingEntity) {
                    livingEntity.method_6092(new class_1293(class_1294.field_5909, 100, 3));
                }
            }
        }
        
        level.method_8396(null, player.method_24515(), class_3417.field_15210, class_3419.field_15248, 1.0F, 1.0F);
    }

    private static void setCooldown(class_1657 player, CultivationTechnique technique, int ticks) {
        cooldowns.computeIfAbsent(player.method_5667(), k -> new HashMap<>()).put(technique, ticks);
    }

    private static boolean isOnCooldown(class_1657 player, CultivationTechnique technique) {
        Map<CultivationTechnique, Integer> playerCooldowns = cooldowns.get(player.method_5667());
        return playerCooldowns != null && playerCooldowns.containsKey(technique) && playerCooldowns.get(technique) > 0;
    }

    private static int getRemainingCooldown(class_1657 player, CultivationTechnique technique) {
        Map<CultivationTechnique, Integer> playerCooldowns = cooldowns.get(player.method_5667());
        return playerCooldowns != null ? playerCooldowns.getOrDefault(technique, 0) : 0;
    }

    public static void updateCooldowns(class_1657 player) {
        UUID uuid = player.method_5667();
        Map<CultivationTechnique, Integer> playerCooldowns = cooldowns.get(uuid);
        
        if (playerCooldowns != null) {
            playerCooldowns.entrySet().removeIf(entry -> {
                entry.setValue(entry.getValue() - 1);
                return entry.getValue() <= 0;
            });
        }
        
        if (shieldTimers.containsKey(uuid)) {
            int remaining = shieldTimers.get(uuid) - 1;
            if (remaining <= 0) {
                shieldTimers.remove(uuid);
            } else {
                shieldTimers.put(uuid, remaining);
            }
        }
        
        if (defenseBoostTimers.containsKey(uuid)) {
            int remaining = defenseBoostTimers.get(uuid) - 1;
            if (remaining <= 0) {
                defenseBoostTimers.remove(uuid);
            } else {
                defenseBoostTimers.put(uuid, remaining);
            }
        }
        
        if (damageBoostTimers.containsKey(uuid)) {
            int remaining = damageBoostTimers.get(uuid) - 1;
            if (remaining <= 0) {
                damageBoostTimers.remove(uuid);
            } else {
                damageBoostTimers.put(uuid, remaining);
            }
        }
    }

    public static boolean hasShield(class_1657 player) {
        return shieldTimers.containsKey(player.method_5667());
    }

    public static boolean hasDefenseBoost(class_1657 player) {
        return defenseBoostTimers.containsKey(player.method_5667());
    }

    public static boolean hasDamageBoost(class_1657 player) {
        return damageBoostTimers.containsKey(player.method_5667());
    }

    public static float getDamageMultiplier(class_1657 player) {
        float multiplier = 1.0F;
        if (hasDamageBoost(player)) {
            multiplier += 0.5F;
        }
        return multiplier;
    }

    public static float getDefenseMultiplier(class_1657 player) {
        float multiplier = 1.0F;
        if (hasDefenseBoost(player)) {
            multiplier += 0.3F;
        }
        return multiplier;
    }

    public static boolean absorbDamage(class_1657 player, float damage) {
        if (hasShield(player)) {
            shieldTimers.remove(player.method_5667());
            return true;
        }
        return false;
    }
}